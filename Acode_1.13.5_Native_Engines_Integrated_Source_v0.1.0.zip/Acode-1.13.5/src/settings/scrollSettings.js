import settingsPage from "components/settingsPage";
import config from "lib/config";
import appSettings from "lib/settings";

export default function scrollSettings() {
	const values = appSettings.value;
	const title = strings["scroll settings"];

	const items = [
		/*{
			key: "scrollSpeed",
			text: strings["scroll speed"],
			value: values.scrollSpeed,
			valueText: getScrollSpeedString,
			select: [
				[constants.SCROLL_SPEED_FAST_X2, `${strings.fast} x2`],
				[constants.SCROLL_SPEED_FAST, strings.fast],
				[constants.SCROLL_SPEED_NORMAL, strings.normal],
				[constants.SCROLL_SPEED_SLOW, strings.slow],
			],
		},*/
		/*{
			key: "reverseScrolling",
			text: strings["reverse scrolling"],
			checkbox: values.reverseScrolling,
		},*/
		/*{
			key: "diagonalScrolling",
			text: strings["diagonal scrolling"],
			checkbox: values.diagonalScrolling,
		},*/
		{
			key: "scrollbarSize",
			text: strings["scrollbar size"],
			value: values.scrollbarSize,
			valueText: (size) => `${size}px`,
			select: [5, 10, 15, 20],
		},
		{
			key: "scrollbarHeight",
			text: strings["scrollbar height"] || "Scrollbar height",
			value: values.scrollbarHeight,
			valueText: (size) => `${size}px`,
			select: [20, 30, 40, 50, 60],
		},
		{
			key: "scrollPastEnd",
			text: strings["scroll past end"],
			value: values.scrollPastEnd ?? "medium",
			info: strings["settings-info-scroll-past-end"],
			valueText: (val) => {
				switch (val) {
					case "none":
						return strings.none;
					case "small":
						return strings.small;
					case "medium":
						return strings.medium;
					default:
						return strings.full;
				}
			},
			select: [
				["none", strings.none],
				["small", strings.small],
				["medium", strings.medium],
				["full", strings.full],
			],
		},
		{
			key: "leftMargin",
			text: strings["horizontal scroll margin"],
			value: values.leftMargin ?? 50,
			valueText: (size) => `${size}px`,
			prompt: strings["horizontal scroll margin"],
			promptType: "number",
			promptOptions: {
				required: true,
				test(value) {
					if (!/^\d+$/.test(String(value).trim())) return false;
					const size = Number(value);
					return Number.isSafeInteger(size) && size >= 0;
				},
			},
			info: strings["settings-info-horizontal-scroll-margin"],
		},
	];

	return settingsPage(title, items, callback, undefined, {
		preserveOrder: true,
		pageClassName: "detail-settings-page",
		listClassName: "detail-settings-list",
		infoAsDescription: true,
		valueInTail: true,
		groupByDefault: true,
	});

	function callback(key, value) {
		appSettings.update({
			[key]: key === "leftMargin" ? Number(value) : value,
		});
	}
}

function getScrollSpeedString(speed) {
	switch (speed) {
		case config.SCROLL_SPEED_FAST:
			return strings.fast;
		case config.SCROLL_SPEED_SLOW:
			return strings.slow;
		case config.SCROLL_SPEED_FAST_X2:
			return `${strings.fast} x2`;
		case config.SCROLL_SPEED_NORMAL:
			return strings.normal;
		default:
			return strings.normal;
	}
}
