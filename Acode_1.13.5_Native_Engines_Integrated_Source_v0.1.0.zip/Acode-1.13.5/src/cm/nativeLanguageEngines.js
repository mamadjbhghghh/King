/*
 * Acode Native Language Engines — built-in host bridge.
 * The language engines are bundled under www/native-language-engines and are not
 * installed as independent Acode plugins. Their existing CodeMirror adapters remain
 * isolated per language while Acode owns app startup and engine lifecycle.
 */
import acode from "lib/acode";
import Page from "components/page";
import languageEngineRegistry from "./languageEngines/registry";

const ENGINE_DEFINITIONS = [
  {
    registryId: "python",
    pluginId: "com.jarvis.python-toolkit-pro.dev",
    folder: "python",
    title: "Python Toolkit Pro",
    languages: ["python"],
    extensions: [".py", ".pyi", ".pyw"],
    priority: 300,
  },
  {
    registryId: "dart",
    pluginId: "com.jarvis.dart-toolkit-pro",
    folder: "dart",
    title: "Dart Toolkit Pro",
    languages: ["dart"],
    extensions: [".dart"],
    priority: 200,
  },
  {
    registryId: "html-css",
    pluginId: "com.jarvis.html-css-toolkit-pro",
    folder: "web",
    title: "HTML/CSS Toolkit Pro",
    languages: ["html", "css", "htmlmixed"],
    extensions: [".html", ".htm", ".xhtml", ".css"],
    priority: 100,
  },
];

let initPromise = null;
let registered = false;
const pages = new Map();
const unregisterHandles = [];

function getBaseUrl(folder) {
  const assetsDirectory = String(window.ASSETS_DIRECTORY || "").replace(/\\/g, "/").replace(/\/+$/u, "");
  if (!assetsDirectory) throw new Error("Acode ASSETS_DIRECTORY is not available");
  return `${assetsDirectory}/native-language-engines/${folder}/`;
}

function loadEngineScript(definition, baseUrl) {
  const scriptId = `acode-native-engine-${definition.folder}-main`;
  const alreadyLoaded = document.getElementById(scriptId);
  if (alreadyLoaded?.dataset?.loaded === "true") return Promise.resolve();

  return new Promise((resolve, reject) => {
    const script = alreadyLoaded || document.createElement("script");
    script.id = scriptId;
    script.async = false;
    script.src = `${baseUrl}main.js`;
    script.onload = () => {
      script.dataset.loaded = "true";
      resolve();
    };
    script.onerror = () => reject(new Error(`Failed to load built-in ${definition.title} engine source`));
    if (!alreadyLoaded) document.head.appendChild(script);
  });
}

function registerNativeEngines() {
  if (registered) return;
  for (const definition of ENGINE_DEFINITIONS) {
    const page = Page(definition.title);
    pages.set(definition.registryId, page);
    unregisterHandles.push(languageEngineRegistry.register({
      id: definition.registryId,
      languages: definition.languages,
      extensions: definition.extensions,
      priority: definition.priority,
      activate: async () => {
        const baseUrl = getBaseUrl(definition.folder);
        // Reuse Acode's existing plugin lifecycle to guarantee the engine receives
        // the same app APIs, while the script itself is shipped inside Acode/www.
        await acode.initPlugin(definition.pluginId, baseUrl, page, {
          native: true,
          builtInLanguageEngine: true,
        });
      },
      deactivate: async () => {
        acode.unmountPlugin(definition.pluginId);
        try { page.hide?.(); } catch (_) {}
      },
    }));
  }
  registered = true;
}

export default function initNativeLanguageEngines() {
  if (initPromise) return initPromise;
  initPromise = (async () => {
    if (!window.acode || typeof acode.initPlugin !== "function") {
      throw new Error("Acode plugin lifecycle API is unavailable");
    }

    registerNativeEngines();

    // If the user had the standalone plugins installed, tear their live instances
    // down before the same engine IDs are rebound to the app-bundled source files.
    for (const definition of ENGINE_DEFINITIONS) {
      try { acode.unmountPlugin(definition.pluginId); } catch (error) {
        console.warn(`[Acode Native Engines] Pre-mount cleanup skipped for ${definition.registryId}`, error);
      }
    }

    const loaded = await Promise.allSettled(ENGINE_DEFINITIONS.map(async definition => {
      const baseUrl = getBaseUrl(definition.folder);
      await loadEngineScript(definition, baseUrl);
    }));

    const scriptFailures = loaded
      .map((result, index) => ({ result, definition: ENGINE_DEFINITIONS[index] }))
      .filter(item => item.result.status === "rejected");

    const activations = await Promise.allSettled(
      ENGINE_DEFINITIONS
        .filter(definition => !scriptFailures.some(item => item.definition.registryId === definition.registryId))
        .map(definition => languageEngineRegistry.activate(definition.registryId)),
    );

    const activationFailures = activations
      .map((result, index) => ({ result, index }))
      .filter(item => item.result.status === "rejected" || item.result.value !== true);

    const failures = [
      ...scriptFailures.map(item => `${item.definition.title}: ${String(item.result.reason?.message || item.result.reason)}`),
      ...activationFailures.map(item => `${ENGINE_DEFINITIONS.filter(definition => !scriptFailures.some(f => f.definition.registryId === definition.registryId))[item.index].title}: activation failed`),
    ];

    window.__ACODE_NATIVE_LANGUAGE_ENGINES__ = Object.freeze({
      version: "0.1.0",
      list: () => languageEngineRegistry.list(),
      resolve: (path, language) => languageEngineRegistry.resolve(path, language),
      shutdown: async () => languageEngineRegistry.dispose(),
    });

    if (failures.length) {
      console.error("[Acode Native Engines] Partial initialization:", failures);
    } else {
      console.info("[Acode Native Engines] Python, Dart, and HTML/CSS engines initialized.");
    }
    return { ok: failures.length === 0, failures, engines: languageEngineRegistry.list() };
  })().catch(error => {
    console.error("[Acode Native Engines] Initialization failed", error);
    initPromise = null;
    throw error;
  });
  return initPromise;
}
