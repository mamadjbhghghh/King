const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const code = fs.readFileSync(__dirname + '/../main.js', 'utf8');
let init, unmount, attached = 0, detached = 0;
class Compartment {
  of(value) { return { compartment: this, value }; }
  get(state) { return state.compartment === this ? state.extension : undefined; }
  reconfigure(value) { return { compartment: this, value }; }
}
const StateEffect = { appendConfig: { of: value => ({ append: value }) } };
const EditorState = { languageData: { of: fn => ({ kind: 'languageData', fn }) } };
const lintApi = {
  linter(source, config) { return { kind: 'linter', source, config }; },
  lintGutter() { return { kind: 'lintGutter' }; },
  lintKeymap: [{ key: 'Ctrl-Shift-m', run() { return true; } }]
};
const viewApi = { keymap: { of: bindings => ({ kind: 'lintKeymap', bindings }) } };
let currentSource = "void main() { final person = (name: 'Ada', age: 37); person.na }";
const file = { type: 'editor', uri: '/project/lib/main.dart', filename: 'main.dart', session: { doc: { toString: () => currentSource } } };
let dependencySource = "class User { String name = 'Ada'; String greet() => 'hello'; }";
const dependencyFile = { type: 'editor', uri: '/project/lib/models.dart', filename: 'models.dart', session: { doc: { toString: () => dependencySource } } };
const view = {
  state: { doc: { toString: () => currentSource }, selection: { main: { from: 0, to: 0, empty: true } } },
  dispatch(tr) {
    if (tr.effects?.append) { this.state.compartment = tr.effects.append.compartment; this.state.extension = tr.effects.append.value; attached++; }
    else if (tr.effects?.compartment) { this.state.extension = tr.effects.value; if (!tr.effects.value.length) detached++; }
  }
};
const managerEvents = [];
const manager = { isCodeMirror: true, editor: view, panes: [], activeFile: file, files: [file, dependencyFile], on(name) { managerEvents.push(name); }, off() {} };
const document = { addEventListener() {}, removeEventListener() {} };
const window = {
  __ACODE_DTP_TESTING__: true,
  editorManager: manager,
  localStorage: { getItem: () => null, setItem() {} },
  acode: {
    require(name) {
      if (name === '@codemirror/state') return { Compartment, StateEffect, EditorState };
      if (name === '@codemirror/lint') return lintApi;
      if (name === '@codemirror/view') return viewApi;
      if (name === '@codemirror/autocomplete') return { pickedCompletion: { of: value => ({ picked: value }) } };
      return null;
    },
    setPluginInit(id, fn) { assert.strictEqual(id, 'com.jarvis.dart-toolkit-pro'); init = fn; },
    setPluginUnmount(id, fn) { assert.strictEqual(id, 'com.jarvis.dart-toolkit-pro'); unmount = fn; },
    pushNotification() {}
  }
};
const sandbox = { window, document, console, setTimeout, clearTimeout, setInterval: () => 1, clearInterval() {}, Date, URL };
vm.runInNewContext(code, sandbox);

function runCompletion(provider, source, cursorMarker = '') {
  currentSource = source;
  const state = { ...view.state, doc: { toString: () => source } };
  const pos = cursorMarker ? source.indexOf(cursorMarker) + cursorMarker.length : source.length;
  const result = provider.autocomplete({ state, pos, view });
  return result?.options?.map(item => item.label) || [];
}

(async () => {
  const api = window.__acodeDTPTest;
  assert.strictEqual(api.TOOLKIT_VERSION, '1.00.13');
  await init();
  assert(attached > 0, 'CodeMirror extension compartment was not attached');
  const extension = view.state.extension;
  assert(Array.isArray(extension), 'combined extension array missing');
  const languageData = extension.find(item => item?.kind === 'languageData');
  const linter = extension.find(item => item?.kind === 'linter');
  const gutter = extension.find(item => item?.kind === 'lintGutter');
  const keymap = extension.find(item => item?.kind === 'lintKeymap');
  assert(languageData && linter && gutter && keymap, 'autocomplete, linter, gutter, and keymap must all attach');
  const providers = languageData.fn(view.state);
  const provider = providers.find(item => typeof item.autocomplete === 'function');
  assert(provider, 'autocomplete provider missing');

  const namedRecord = "void main() { final person = (name: 'Ada', age: 37); person.na";
  assert(runCompletion(provider, namedRecord).includes('name'), 'named record field was not suggested');

  const positionalRecord = "void main() { final pair = ('Ada', 37); pair.$1.to";
  assert(runCompletion(provider, positionalRecord).includes('toUpperCase'), 'positional record field type was not followed through member completion');

  const switchPattern = "void main() { final pair = ('Ada', 37); switch (pair) { case (var name, var age): name.to; break; default: break; } }";
  assert(runCompletion(provider, switchPattern, 'name.to').includes('toUpperCase'), 'switch-pattern local did not receive String completions');

  const objectPattern = "class User {\n String name;\n int age;\n}\nvoid main() { final user = User(); if (user case User(:final name, :final age)) { name.to; } }";
  assert(runCompletion(provider, objectPattern, 'name.to').includes('toUpperCase'), 'object-pattern property binding did not receive String completions');

  const outOfScope = "void main() { final value = 'hello'; if (value case String hidden) { print(hidden); } hidden.to; }";
  assert(!runCompletion(provider, outOfScope, 'hidden.to').includes('toUpperCase'), 'if-case variable leaked outside its branch');

  const loopBinding = "void main() { for (final item in <String>[]) { item.to";
  assert(runCompletion(provider, loopBinding, 'item.to').includes('toUpperCase'), 'AST-derived for-in element type was not used by live completion');

  const nullableLocal = "void main() { final List<int>? values = null; values; }";
  const nullableAst = api.parseDartAst(nullableLocal);
  assert(nullableAst.variables.some(item => item.name === 'values' && item.declaredType === 'List<int>?'), 'nullable generic local declaration was not parsed');

  const parserDiagnostics = linter.source({ state: { doc: { toString: () => 'class { int value = 1; }' } } });
  assert(parserDiagnostics.some(item => item.code === 'ast-missing-type-name'), 'AST parser diagnostics were not connected to CodeMirror lint');

  const cache = api.createDartAnalysisCache(2);
  const parsedA = cache.analyze('/project/a.dart', 'class A {}');
  assert.strictEqual(cache.analyze('/project/a.dart', 'class A {}'), parsedA, 'unchanged source did not reuse cached syntax tree');
  assert.strictEqual(cache.stats().hits, 1, 'analysis cache hit was not counted');

  const diagnostics = linter.source({ state: { doc: { toString: () => 'void main() {  \n}' } } });
  assert(diagnostics.some(item => item.code === 'trailing-whitespace'), 'existing lint diagnostics stopped working');
  assert(linter.config.delay >= 500, 'diagnostics debounce regressed');

  const indexedString = "void main() { final values = <String>['Ada']; final item = values[0]; item.to; }";
  const indexedStringOptions = runCompletion(provider, indexedString, 'item.to');
  assert(indexedStringOptions.includes('toUpperCase') && !indexedStringOptions.includes('toInt'), 'index expression did not flow its String element type into completion');

  const awaitedInt = 'void main() async { final count = await Future<int>.value(3); count.to; }';
  const awaitedIntOptions = runCompletion(provider, awaitedInt, 'count.to');
  assert(awaitedIntOptions.includes('toInt') && !awaitedIntOptions.includes('toUpperCase'), 'await expression did not unwrap Future<int> for live completion');

  const conditionalString = "void main() { final label = 'Ada'; final result = true ? label : 'Grace'; result.to; }";
  const conditionalOptions = runCompletion(provider, conditionalString, 'result.to');
  assert(conditionalOptions.includes('toUpperCase') && !conditionalOptions.includes('toInt'), 'conditional initializer inherited the condition type instead of branch type');

  const mapValue = "void main() { final values = <String, int>{'age': 37}; final age = values['age']; age.to; }";
  const mapValueOptions = runCompletion(provider, mapValue, 'age.to');
  assert(mapValueOptions.includes('toInt') && !mapValueOptions.includes('toUpperCase'), 'Map index expression did not infer the value type');


  const genericFactory = "void main() { final values = List<String>.filled(2, 'x'); values[0].to; }";
  const genericFactoryOptions = runCompletion(provider, genericFactory, 'values[0].to');
  assert(genericFactoryOptions.includes('toUpperCase') && !genericFactoryOptions.includes('toInt'), 'generic List factory lost its element type through indexed access');

  const divisionResult = 'void main() { final ratio = 10 / 2; ratio.to; }';
  const divisionOptions = runCompletion(provider, divisionResult, 'ratio.to');
  assert(divisionOptions.includes('toDouble') && !divisionOptions.includes('toUpperCase'), 'division expression was not inferred as double');

  const nullableFallback = "void main() { String? label; final resolved = label ?? 'fallback'; resolved.to; }";
  const fallbackOptions = runCompletion(provider, nullableFallback, 'resolved.to');
  assert(fallbackOptions.includes('toUpperCase') && !fallbackOptions.includes('toInt'), 'null-coalescing expression did not preserve non-null String type');

  const methodChain = "class User {\n String greet() => 'hello';\n}\nvoid main() { final user = User(); final name = user.greet(); name.to; }";
  const methodChainOptions = runCompletion(provider, methodChain, 'name.to');
  assert(methodChainOptions.includes('toUpperCase') && !methodChainOptions.includes('toInt'), 'user-defined method return type did not reach live member completion');

  const importedSource = "import 'models.dart';\nvoid main() { final user = User(); user.na }";
  const importedOptions = runCompletion(provider, importedSource, 'user.na');
  assert(importedOptions.includes('name') && !importedOptions.includes('age'), 'shared semantic graph failed to supply open imported class members');
  dependencySource = `class User { int age = 37; String greet() => 'hello'; }`;
  const updatedImportSource = "import 'models.dart';\nvoid main() { final user = User(); user.ag }";
  const updatedImportOptions = runCompletion(provider, updatedImportSource, 'user.ag');
  assert(updatedImportOptions.includes('age') && !updatedImportOptions.includes('name'), 'dependency edit did not refresh dependent completion without stale members');
  assert(managerEvents.includes('rename-file') && managerEvents.includes('switch-file'), 'editor lifecycle events were not subscribed');
  unmount();
  assert(detached > 0, 'combined extension compartment was not removed on unload');

  // Compatibility path: autocomplete remains available if Acode lacks @codemirror/lint.
  let fallbackInit, fallbackUnmount;
  const fallbackSource = "void main() { final pair = ('Ada', 37); pair.$1.to";
  const fallbackView = { state: { doc: { toString: () => fallbackSource } }, dispatch(tr) { if (tr.effects?.append) { this.state.extension = tr.effects.append.value; this.state.compartment = tr.effects.append.compartment; } } };
  const fallbackFile = { type: 'editor', uri: '/project/fallback.dart', session: { doc: { toString: () => fallbackSource } } };
  const fallbackWindow = {
    editorManager: { isCodeMirror: true, editor: fallbackView, panes: [], activeFile: fallbackFile, files: [fallbackFile], on() {}, off() {} },
    acode: {
      require(name) { return name === '@codemirror/state' ? { Compartment, StateEffect, EditorState } : (name === '@codemirror/autocomplete' ? { pickedCompletion: { of: value => ({ picked: value }) } } : null); },
      setPluginInit(id, fn) { fallbackInit = fn; }, setPluginUnmount(id, fn) { fallbackUnmount = fn; }, pushNotification() {}
    }
  };
  const fallbackSandbox = { window: fallbackWindow, document, console, setTimeout, clearTimeout, setInterval: () => 1, clearInterval() {}, Date, URL };
  vm.runInNewContext(code, fallbackSandbox);
  await fallbackInit();
  assert(Array.isArray(fallbackView.state.extension) && fallbackView.state.extension.length === 1, 'completion-only fallback extension missing');
  const fallbackProvider = fallbackView.state.extension[0].fn(fallbackView.state).find(item => typeof item.autocomplete === 'function');
  assert(fallbackProvider, 'completion provider missing in lint fallback mode');
  const fallbackResult = fallbackProvider.autocomplete({ state: fallbackView.state, pos: fallbackSource.length, view: fallbackView });
  assert(fallbackResult && fallbackResult.options.some(item => item.label === 'toUpperCase'), 'record type inference failed in lint fallback mode');
  fallbackUnmount();


  console.log('PASS plugin init attaches combined completion and lint extensions');
  console.log('PASS named record field completion works through live provider');
  console.log('PASS positional record member types flow into chained completions');
  console.log('PASS switch pattern locals receive inferred type completions');
  console.log('PASS object pattern bindings receive inferred class-field completions');
  console.log('PASS if-case locals do not leak outside their branch');
  console.log('PASS existing lint diagnostics, debounce and editor lifecycle remain intact');
  console.log('PASS unmount removes the complete extension compartment');
  console.log('PASS completion-only compatibility mode retains new record intelligence');
  console.log('PASS indexed collection expression provides element-type completion');
  console.log('PASS await expression provides unwrapped Future payload completion');
  console.log('PASS conditional expression uses branch type for completion');
  console.log('PASS Map index expression provides value-type completion');
  console.log('PASS generic List factory retains type through index completion');
  console.log('PASS division result is inferred as double in live completion');
  console.log('PASS null-coalescing expression preserves non-null String completion');
  console.log('PASS user-defined method return type flows into chained completion');
  console.log('PASS shared semantic graph resolves imported open-document members');
  console.log('PASS dependency edits refresh dependent completions without stale members');
  console.log('RESULT 19/19 PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
