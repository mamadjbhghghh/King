# Native Language Engine Integration — Candidate 0.1.0

## Host and engine baselines

- Acode 1.13.5 / CodeMirror 6.
- Python Toolkit Pro 3.00 full-integration release candidate.
- Dart Toolkit Pro 1.00.13.
- HTML/CSS Toolkit Pro 1.00.04.

## Current integration design

Acode owns application startup and the lifecycle entry point. `src/cm/nativeLanguageEngines.js` registers Python, Dart and HTML/CSS in the shared `LanguageEngineRegistry`, loads the bundled source scripts from `www/native-language-engines/`, and activates each engine through Acode's `setPluginInit` / `initPlugin` APIs. The source scripts are shipped in the app and do not need separate installation.

The existing engine implementations retain their own CodeMirror compartments and editor reconciliation logic. They are language/path scoped, so each engine handles only its matching file types. This is an intentional compatibility bridge for the first native build; it is not yet the final single-source CodeMirror completion architecture.

## Why the existing engine adapters are retained temporarily

P.T.P, D.T.P and H.S.T.P contain mature private engine implementations. A direct rewrite into a new provider API would change parser, scope, semantic graph, completion ranking, multi-file indexing, ghost preview and editor lifecycle behavior simultaneously. The first native candidate therefore keeps the proven implementations intact and moves their source and startup ownership into Acode. This minimizes logic changes while establishing a device-testable built-in path.

## Native startup sequence

1. Acode loads its normal dependencies and initializes `window.acode`, `window.editorManager` and the app UI.
2. Acode loads any user-installed plugins using its standard plugin manager.
3. The native bridge unmounts any live standalone copies using the same upstream IDs, preventing duplicate active engines.
4. The built-in engine scripts are loaded from the packaged `www/native-language-engines/` directory.
5. The host registry activates Python, Dart and HTML/CSS and Acode re-emits the active-file events.

## Deferred P.T.P modules

Pyodide runtime (Python execution) and Material Icons Advanced are marked `detached` in the native P.T.P module registry. They are separate from IntelliSense and require additional runtime/resource and app-UI migration. P.T.P supporting assets used by remaining auxiliary editor tools are preserved under its native asset directory.

## Remaining integration phases

- Replace per-toolkit CodeMirror compartments with a single Acode-owned completion arbitration layer.
- Move each private completion provider behind a stable native adapter API.
- Route diagnostics, document updates, workspace indexing, formatting and editor commands through host-owned services.
- Reintegrate Pyodide runtime, icons, themes, terminal, debugger and other non-core services with explicit lifecycle and resource ownership.
- Run the complete existing regression suites and real Acode Android acceptance tests.

## Stability gate

Do not call this candidate stable until it compiles, launches on Android, passes all three language test sets, survives repeated file switching and multi-pane use, and has no duplicate or cross-language completions.
