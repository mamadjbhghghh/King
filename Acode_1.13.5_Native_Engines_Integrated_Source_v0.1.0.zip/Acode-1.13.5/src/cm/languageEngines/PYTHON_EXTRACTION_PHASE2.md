# Phase 2 — Python engine extraction boundary

## Source baseline

- P.T.P source: `3.00_Python_Toolkit_Pro_Full_Integration_Release_Candidate.zip`
- Audited plugin source snapshot: `main.js` from the supplied P.T.P package (Build 3.00 RC; lineage through 2.00.116).
- Acode host: 1.13.5 / CodeMirror 6.

## Confirmed extraction seam

P.T.P publishes an internal bridge named `window.__ACODE_AUTOCOMPLETE_AI_MODULE__` before registering its plugin lifecycle. The bridge currently exposes:

- `create()` — constructs the private `AutocompleteAI` instance.
- `checkPythonIssues(source)` — reuses the existing Python issue heuristics.
- `maskPythonNonCode(source)` — shared lexical masking used by adjacent P.T.P subsystems.

The `AutocompleteAI` instance owns its own completion compartment and editor discovery/reconciliation. That is the key migration seam, but it is not yet a native Acode engine: its `init(baseUrl, page, options)` path also depends on plugin lifecycle and plugin asset URLs. Moving the whole P.T.P `main.js` into Acode would also pull runtime, theme, terminal, quick-tool, breakpoint and other non-language systems into the editor bundle. This is explicitly rejected.

## Phase 2 implementation in this source tree

The host registry now supports document-routed completion dispatch (`complete(context)`) and prefers an explicit language identity over a colliding extension. Unregistering an active engine initiates teardown without allowing a rejected asynchronous teardown to become an unhandled rejection. Unit tests cover active-only dispatch and language-vs-extension precedence.

## Remaining Python extraction work

The actual Python semantic implementation remains private inside the P.T.P bundle. It must be split into a language-only module with an explicit API, without copying plugin shell behavior:

1. `createPythonEngine(hostServices)`
2. `activate()` / `deactivate()` (idempotent)
3. `complete({ state, pos, path, view, workspace })`
4. `diagnose({ state, path, view })`
5. `updateDocument(...)` / `removeDocument(...)` for multi-file semantic index lifecycle

The extraction must preserve P.T.P's parser, scope/symbol graph, type inference, call-chain analysis, import/workspace index, semantic ranking and Ghost Preview algorithms. Ghost UI, runtime, themes, terminal, settings, icons and breakpoints are separate migration tracks.

## Safety gate

Do not mark Python migrated until the native engine is bundled by Acode itself, starts without installing P.T.P, survives file switching and multiple panes, and passes the existing P.T.P engine tests plus real Acode device tests. This phase does not claim that gate has passed.
