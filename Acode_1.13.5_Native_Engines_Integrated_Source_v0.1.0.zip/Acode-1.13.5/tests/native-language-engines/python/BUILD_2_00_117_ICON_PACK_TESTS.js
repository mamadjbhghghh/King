const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = __dirname;
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const parse = p => JSON.parse(read(p));
const main = read('main.js');
const manifest = parse('plugin.json');
const modules = parse('ptp-modules.json');
const icons = parse('assets/material-icons-advanced.json');
let pass = 0, fail = 0;
function check(name, condition, detail = '') {
  if (condition) pass++; else fail++;
  console.log(`${condition ? 'PASS' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
}
function extractArray(name) {
  const match = main.match(new RegExp(`const\\s+${name}\\s*=\\s*(\\[.*?\\]);`, 's'));
  if (!match) throw new Error(`Cannot locate ${name}`);
  return JSON.parse(match[1]);
}
const names = extractArray('assetNames');
const fileDefs = extractArray('fileIconDefinitions');
const folderDefs = extractArray('folderIconDefinitions');
const keys = Object.keys(icons);
const keySet = new Set(keys);
const iconModule = modules.attached_modules.find(x => x.id === 'ptp.material-icons-advanced');
const runtimeModule = modules.attached_modules.find(x => x.id === 'ptp.pyodide-runtime');

check('manifest version and internal TOOLKIT_VERSION match 3.00', manifest.version === '3.00' && main.includes('const TOOLKIT_VERSION = "3.00"'));
check('module registry declares both Runtime and Material Icons as attached', main.includes('materialIconsAdvanced: Object.freeze({ id: "ptp.material-icons-advanced", state: "attached"') && main.includes('pyodideRuntime: Object.freeze({ id: "ptp.pyodide-runtime", state: "attached"'));
check('modular manifest has no detached modules', Array.isArray(modules.detached_modules) && modules.detached_modules.length === 0);
check('Material Icons module is attached and declares 858 assets', Boolean(iconModule && iconModule.status === 'attached' && iconModule.iconCount === 858 || iconModule && iconModule.status === 'attached' && iconModule.payload.includes('assets/material-icons-advanced.json')));
check('Pyodide runtime attachment from previous build is retained', Boolean(runtimeModule && runtimeModule.status === 'attached' && runtimeModule.payload.includes('python-runtime/runtime-main.js')));
check('icon JSON contains exactly 858 unique entries', keys.length === 858 && keySet.size === 858);
check('icon JSON keys exactly match main.js asset catalog', names.length === 858 && names.every(n => keySet.has(n)) && keys.every(n => names.includes(n)));
check('all 858 SVG values have a valid SVG root marker', keys.every(k => typeof icons[k] === 'string' && /<svg\b/i.test(icons[k]) && /<\/svg>\s*$/i.test(icons[k].trim())));
check('SVG payload contains no script or foreignObject elements', keys.every(k => !/<\s*(?:script|foreignObject)\b/i.test(icons[k])));
check('SVG payload contains no inline event-handler attributes', keys.every(k => !/\son[a-z]+\s*=/i.test(icons[k])));
check('SVG payload contains no javascript: URLs', keys.every(k => !/javascript\s*:/i.test(icons[k])));
check('SVG payload contains no external href or CSS url references', keys.every(k => !/(?:href|xlink:href)\s*=\s*[\"']\s*(?:https?:|\/\/|data:text\/html)|url\(\s*[\"']?\s*(?:https?:|\/\/)/i.test(icons[k])));
check('six critical SVGs are present', ['document','python','folder','folder-open','folder-root','folder-root-open'].every(n => keySet.has(n)));
check('426 file icon definitions resolve to bundled SVG assets', fileDefs.length === 426 && fileDefs.every(d => keySet.has(d.name)));
check('191 folder definitions resolve to bundled SVG assets', folderDefs.length === 191 && folderDefs.every(d => keySet.has(d.name)));
check('named folder open-state assets are present or use generic fallback', folderDefs.every(d => keySet.has(`${d.name}-open`) || keySet.has('folder-open')));
check('Python file extension remains mapped to python.svg', main.includes('{"name":"python","file_extensions":["py"]}') && keySet.has('python'));
check('package manifest declares the local icon data asset', manifest.files.includes('assets/material-icons-advanced.json') && fs.existsSync(path.join(root, 'assets/material-icons-advanced.json')));
check('integrity metadata declares exact source payload match', read('assets/MATERIAL_ICONS_ADVANCED_INTEGRITY.txt').includes('Exact UTF-8 SVG payload matches against supplied archive: 858/858'));
check('module payload hashes match packaged local assets', Boolean(iconModule && Object.entries(iconModule.sha256).every(([p,h]) => crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex') === h)));
check('icon loader uses the packaged JSON and preserves native fallback', main.includes('assets/material-icons-advanced.json') && main.includes('native Acode icons were kept unchanged'));
check('icon renderer cleanup is connected to P.T.P unmount', main.includes('cancelIconActivationRetries();') && main.includes('removeLegacyPtpIconFallback();') && main.includes('releasePtpMaterialIconUrls();'));
check('icon module uses the existing P.T.P plugin identity', manifest.id === 'com.jarvis.python-toolkit-pro.dev' && main.includes('pluginId: "com.jarvis.python-toolkit-pro.dev"'));
check('runtime and icon module metadata use the current build', modules.base_build === '3.00' && modules.profile === 'full-integration-release-candidate');
check('all manifest-declared files exist', manifest.files.every(p => fs.existsSync(path.join(root,p))));
console.log(`SUMMARY ${pass}/${pass + fail} PASS; ${fail} FAIL`);
if (fail) process.exitCode = 1;
