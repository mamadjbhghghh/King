# H.S.T.P 1.00.04 — Change Audit

## Root causes addressed

1. Multi-line snippet completions used a custom dispatching `apply` callback but did not attach CodeMirror's `pickedCompletion` annotation. CodeMirror's completion contract requires custom apply transactions to carry this annotation so the completion system can recognize the selected completion and close/update its UI correctly.
2. HTML snippets used a distinct `text` row type and custom `displayLabel` text, visually separating them from ordinary suggestions despite sharing the same source.
3. The completion parser already performed strict prefix filtering, but CodeMirror then filtered and re-ranked the returned options again. This could disturb the intentionally curated context and recent-use ordering.
4. Suggestions did not persist accepted-item history or prioritize recently selected items.

## Implemented

- All returned suggestions now expose one uniform function-based `apply` contract. String insertions and context-aware insertions pass through the same wrapper.
- Every custom apply transaction adds `pickedCompletion.of(completion)` when the Acode-provided CodeMirror autocomplete API exposes it.
- HTML and CSS multi-line snippets now use the standard `keyword` completion row type and their concise trigger as the label. Description remains in `detail`; snippet payload is closed over by the apply callback rather than attached as ad-hoc completion metadata.
- The completion source returns `filter: false` after performing its own strict contextual prefix filtering. This preserves the parser's exact order and prevents CodeMirror from re-sorting those options a second time.
- Accepted suggestions are persisted in the shared Toolkit Pro storage schema:
  - Key: `com.jarvis.toolkit-pro.recent-completions.v1`
  - Version: `1`
  - Entry: `{ key, usedAt, order }`
  - Per-extension namespace: `com.jarvis.html-css-toolkit-pro|<type>|<label>`
  - Maximum retained entries: 300
- Most recently accepted matching items appear first; never-used items retain curated default order. Recent history is persisted across Acode restarts.
- Storage access is guarded; unavailable storage does not block completion.

## Family-wide contract

The shared storage key and entry format are now the required Toolkit Pro family contract. D.T.P and R.T.P must implement the same schema and ranking policy in their next development builds. Each extension filters by its own plugin ID so HTML/CSS history does not contaminate Dart or Rust suggestions.

## Compatibility and safety

- Existing HTML/CSS completion contexts, tag pairing, attribute insertion, CSS scaffolding, and templates are retained.
- `displayLabel` remains only where semantically required to display full HTML tag spelling such as `<h1>`; it does not create a separate popup or preview UI.
- No separate popup, Ghost Text, inline preview, custom info panel, network access, or additional runtime dependency is introduced.
