# Native language-engine integration status — Phase 2

- [x] Acode 1.13.5 source baseline retained.
- [x] Shared registry with lifecycle, routing and deterministic priority.
- [x] Active-only document-routed completion dispatch.
- [x] Explicit language identity takes precedence over extension fallback.
- [x] Async teardown rejection is contained during unregister.
- [x] Python extraction seam documented against the supplied P.T.P source.
- [ ] Python semantic implementation physically extracted from P.T.P bundle.
- [ ] Python engine registered and loaded by native Acode startup.
- [ ] Dart and HTML/CSS extraction.
- [ ] Unified CodeMirror completion integration.
- [ ] Native diagnostics and formatting integration.
- [ ] Android build and real-device acceptance.

No original toolkit capability has been removed. No native language engine is claimed as migrated yet.
