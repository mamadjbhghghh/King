import { Diagnostic, linter, lintGutter } from "@codemirror/lint";
import type { LSPClient } from "@codemirror/lsp-client";
import { LSPPlugin } from "@codemirror/lsp-client";
import type { Extension } from "@codemirror/state";
import {
	EditorState,
	MapMode,
	StateEffect,
	StateField,
} from "@codemirror/state";
import { type EditorView, ViewPlugin, type ViewUpdate } from "@codemirror/view";
import { addLspLogFor } from "./logs";
import { safeLspPositionToOffset } from "./positionUtils";
import type {
	DocumentDiagnosticParams,
	DocumentDiagnosticReport,
	LSPClientWithWorkspace,
	LSPPluginAPI,
	LspDiagnostic,
	PublishDiagnosticsParams,
	RawDiagnostic,
} from "./types";

interface PublishedDiagnosticsUpdate {
	client?: LSPClient;
	diagnostics?: LspDiagnostic[];
	clearAll?: boolean;
}

const setPublishedDiagnostics =
	StateEffect.define<PublishedDiagnosticsUpdate>();
let diagnosticsEventTimer: ReturnType<typeof setTimeout> | null = null;
let diagnosticsViewCount = 0;

export const LSP_DIAGNOSTICS_EVENT = "acode:lsp-diagnostics-updated";
const PULL_DIAGNOSTICS_DELAY = 250;

interface PullDiagnosticsState {
	timers: Map<string, ReturnType<typeof setTimeout>>;
	generations: Map<string, number>;
	resultIds: Map<string, string>;
	failures: Map<string, number>;
}

const pullDiagnosticsStates = new WeakMap<LSPClient, PullDiagnosticsState>();

function getPullDiagnosticsState(client: LSPClient): PullDiagnosticsState {
	let state = pullDiagnosticsStates.get(client);
	if (!state) {
		state = {
			timers: new Map(),
			generations: new Map(),
			resultIds: new Map(),
			failures: new Map(),
		};
		pullDiagnosticsStates.set(client, state);
	}
	return state;
}

function supportsPullDiagnostics(client: LSPClient): boolean {
	return !!client.serverCapabilities?.diagnosticProvider;
}

function diagnosticsEnabledForFile(client: LSPClient, uri: string): boolean {
	const file = client.workspace.getFile(uri);
	const view = file?.getView();
	const plugin = view && LSPPlugin.get(view, client);
	return !!plugin?.featureEnabled("diagnostics");
}

function isCoarsePointerDevice(): boolean {
	if (typeof window !== "undefined") {
		try {
			if (window.matchMedia?.("(pointer: coarse)").matches) {
				return true;
			}
		} catch (_) {
			// Ignore matchMedia failures and fall back to maxTouchPoints.
		}
	}

	return (
		typeof navigator !== "undefined" &&
		Number(navigator.maxTouchPoints || 0) > 0
	);
}

function emitDiagnosticsUpdated(): void {
	if (
		typeof document === "undefined" ||
		typeof document.dispatchEvent !== "function"
	) {
		return;
	}

	let event: CustomEvent | Event;
	try {
		event = new CustomEvent(LSP_DIAGNOSTICS_EVENT);
	} catch (_) {
		try {
			event = document.createEvent("CustomEvent");
			(event as CustomEvent).initCustomEvent(
				LSP_DIAGNOSTICS_EVENT,
				false,
				false,
				undefined,
			);
		} catch (_) {
			return;
		}
	}

	document.dispatchEvent(event);
}

function clearScheduledDiagnosticsUpdated(): void {
	if (diagnosticsEventTimer == null) return;
	clearTimeout(diagnosticsEventTimer);
	diagnosticsEventTimer = null;
}

const lspPublishedDiagnostics = StateField.define<
	ReadonlyMap<LSPClient, LspDiagnostic[]>
>({
	create(): ReadonlyMap<LSPClient, LspDiagnostic[]> {
		return new Map();
	},
	update(value: ReadonlyMap<LSPClient, LspDiagnostic[]>, tr) {
		let next = value;
		if (tr.docChanged && value.size) {
			next = new Map();
			for (const [client, diagnostics] of value) {
				const mapped: LspDiagnostic[] = [];
				for (const diagnostic of diagnostics) {
					const from = tr.changes.mapPos(
						diagnostic.from,
						1,
						MapMode.TrackDel,
					);
					const to = tr.changes.mapPos(
						diagnostic.to,
						-1,
						MapMode.TrackDel,
					);
					if (from != null && to != null) {
						mapped.push({ ...diagnostic, from, to });
					}
				}
				(next as Map<LSPClient, LspDiagnostic[]>).set(client, mapped);
			}
		}
		for (const effect of tr.effects) {
			if (effect.is(setPublishedDiagnostics)) {
				if (effect.value.clearAll) {
					next = new Map();
				} else if (effect.value.client) {
					const updated = new Map(next);
					if (effect.value.diagnostics?.length) {
						updated.set(effect.value.client, effect.value.diagnostics);
					} else {
						updated.delete(effect.value.client);
					}
					next = updated;
				}
			}
		}
		return next;
	},
});

type DiagnosticSeverity = "error" | "warning" | "info" | "hint";
const severities: DiagnosticSeverity[] = [
	"hint",
	"error",
	"warning",
	"info",
	"hint",
];

function collectLspDiagnostics(
	plugin: LSPPluginAPI,
	diagnostics: RawDiagnostic[],
): LspDiagnostic[] {
	const items: LspDiagnostic[] = [];
	for (const diagnostic of diagnostics) {
		let from: number;
		let to: number;
		try {
			const mappedFrom = safeLspPositionToOffset(
				plugin.syncedDoc,
				diagnostic.range.start,
			);
			const mappedTo = safeLspPositionToOffset(
				plugin.syncedDoc,
				diagnostic.range.end,
			);
			const fromResult = plugin.unsyncedChanges.mapPos(mappedFrom);
			const toResult = plugin.unsyncedChanges.mapPos(mappedTo);
			if (fromResult === null || toResult === null) continue;
			from = fromResult;
			to = toResult;
		} catch (_) {
			continue;
		}
		if (to > plugin.unsyncedChanges.newLength) continue;

		const severity = severities[diagnostic.severity ?? 0] ?? "info";
		const source = diagnostic.code
			? `${diagnostic.source ? `${diagnostic.source}-` : ""}${diagnostic.code}`
			: undefined;

		items.push({
			from,
			to,
			severity,
			message: diagnostic.message,
			source,
		});
	}

	return items;
}

function storeLspDiagnostics(
	client: LSPClient,
	items: LspDiagnostic[],
): StateEffect<PublishedDiagnosticsUpdate> {
	return setPublishedDiagnostics.of({ client, diagnostics: items });
}

function sameDiagnostics(
	current: readonly LspDiagnostic[],
	next: readonly LspDiagnostic[],
): boolean {
	if (current.length !== next.length) return false;
	for (let index = 0; index < current.length; index++) {
		const left = current[index];
		const right = next[index];
		if (
			left.from !== right.from ||
			left.to !== right.to ||
			left.severity !== right.severity ||
			left.message !== right.message ||
			left.source !== right.source
		) {
			return false;
		}
	}
	return true;
}

function applyDiagnostics(
	client: LSPClient,
	uri: string,
	version: number | undefined,
	rawDiagnostics: RawDiagnostic[],
): boolean {
	const clientWithWorkspace = client as unknown as LSPClientWithWorkspace;
	const file = clientWithWorkspace.workspace.getFile(uri);
	if (!file || (version != null && version !== file.version)) {
		return false;
	}
	const view = file.getView();
	if (!view) return false;
	const plugin = LSPPlugin.get(view, client);
	if (!plugin || !plugin.featureEnabled("diagnostics")) return false;

	const diagnostics = collectLspDiagnostics(
		plugin as unknown as LSPPluginAPI,
		rawDiagnostics,
	);
	const current =
		view.state.field(lspPublishedDiagnostics, false)?.get(client) ?? [];
	if (sameDiagnostics(current, diagnostics)) {
		return true;
	}

	view.dispatch({
		effects: storeLspDiagnostics(client, diagnostics),
	});
	scheduleDiagnosticsUpdated();
	return true;
}

async function pullDiagnostics(
	client: LSPClient,
	uri: string,
	generation: number,
): Promise<void> {
	if (
		!supportsPullDiagnostics(client) ||
		!diagnosticsEnabledForFile(client, uri)
	) {
		return;
	}

	client.sync();
	const clientWithWorkspace = client as unknown as LSPClientWithWorkspace;
	const file = clientWithWorkspace.workspace.getFile(uri);
	if (!file) return;

	const state = getPullDiagnosticsState(client);
	const version = file.version;
	const provider = client.serverCapabilities?.diagnosticProvider;
	const params: DocumentDiagnosticParams = {
		textDocument: { uri },
	};
	if (
		provider &&
		typeof provider === "object" &&
		"identifier" in provider &&
		typeof provider.identifier === "string"
	) {
		params.identifier = provider.identifier;
	}
	const previousResultId = state.resultIds.get(uri);
	if (previousResultId !== undefined) {
		params.previousResultId = previousResultId;
	}

	try {
		const report = await client.request<
			DocumentDiagnosticParams,
			DocumentDiagnosticReport
		>("textDocument/diagnostic", params);
		if (state.generations.get(uri) !== generation) return;
		state.failures.delete(uri);

		const currentFile = clientWithWorkspace.workspace.getFile(uri);
		if (!currentFile || currentFile.version !== version) {
			schedulePullDiagnostics(client, uri, 0);
			return;
		}

		if (report.kind === "unchanged") {
			state.resultIds.set(uri, report.resultId);
			return;
		}

		if (typeof report.resultId === "string") {
			state.resultIds.set(uri, report.resultId);
		} else {
			state.resultIds.delete(uri);
		}
		applyDiagnostics(client, uri, version, report.items);
	} catch (error) {
		if (state.generations.get(uri) === generation) {
			const message =
				error instanceof Error ? error.message : String(error);
			const failures = (state.failures.get(uri) ?? 0) + 1;
			state.failures.set(uri, failures);
			if (/timed out/i.test(message) && failures <= 2) {
				schedulePullDiagnostics(client, uri, failures * 750);
				return;
			}
			addLspLogFor(
				client,
				"warn",
				`Diagnostic pull failed for ${uri}: ${message}`,
				error,
			);
			console.warn(`[LSP:Diagnostics] Pull failed for ${uri}`, error);
		}
	}
}

export function schedulePullDiagnostics(
	client: LSPClient,
	uri: string,
	delay = PULL_DIAGNOSTICS_DELAY,
): void {
	if (!diagnosticsEnabledForFile(client, uri)) return;
	if (!supportsPullDiagnostics(client)) {
		if (client.connected && !client.serverCapabilities) {
			void client.initializing
				.then(() => {
					schedulePullDiagnostics(client, uri, delay);
				})
				.catch(() => {});
		}
		return;
	}

	const state = getPullDiagnosticsState(client);
	const existing = state.timers.get(uri);
	if (existing != null) clearTimeout(existing);

	const generation = (state.generations.get(uri) ?? 0) + 1;
	state.generations.set(uri, generation);
	state.timers.set(
		uri,
		setTimeout(() => {
			state.timers.delete(uri);
			void pullDiagnostics(client, uri, generation);
		}, Math.max(0, delay)),
	);
}

export function schedulePullDiagnosticsForOpenFiles(
	client: LSPClient,
	delay = 0,
): void {
	if (!supportsPullDiagnostics(client)) return;
	for (const file of client.workspace.files) {
		schedulePullDiagnostics(client, file.uri, delay);
	}
}

export function forgetPullDiagnostics(client: LSPClient, uri: string): void {
	const state = pullDiagnosticsStates.get(client);
	if (!state) return;
	const timer = state.timers.get(uri);
	if (timer != null) clearTimeout(timer);
	state.timers.delete(uri);
	state.generations.delete(uri);
	state.resultIds.delete(uri);
	state.failures.delete(uri);
}

export function disposePullDiagnostics(client: LSPClient): void {
	const state = pullDiagnosticsStates.get(client);
	if (!state) return;
	for (const timer of state.timers.values()) {
		clearTimeout(timer);
	}
	state.generations.clear();
	state.failures.clear();
	pullDiagnosticsStates.delete(client);
}

export function lspDiagnosticsAutoSyncExtension(): Extension {
	return ViewPlugin.fromClass(
		class {
			pending: ReturnType<typeof setTimeout> | null = null;
			view: EditorView;

			constructor(view: EditorView) {
				this.view = view;
				this.schedule(0);
			}

			update(update: ViewUpdate): void {
				if (!update.docChanged) return;
				this.schedule(500);
			}

			schedule(delay: number): void {
				if (this.pending != null) clearTimeout(this.pending);
				this.pending = setTimeout(() => this.flush(), delay);
			}

			flush(): void {
				this.pending = null;
				for (const plugin of LSPPlugin.getAll(this.view, "diagnostics")) {
					plugin.client.sync();
					schedulePullDiagnostics(plugin.client, plugin.uri, 0);
				}
			}

			destroy(): void {
				if (this.pending != null) clearTimeout(this.pending);
			}
		},
	);
}

function scheduleDiagnosticsUpdated(): void {
	if (diagnosticsEventTimer != null) return;
	diagnosticsEventTimer = setTimeout(() => {
		diagnosticsEventTimer = null;
		if (diagnosticsViewCount > 0) {
			emitDiagnosticsUpdated();
		}
	}, 32);
}

const diagnosticsLifecyclePlugin = ViewPlugin.fromClass(
	class {
		constructor() {
			diagnosticsViewCount++;
		}

		destroy(): void {
			diagnosticsViewCount = Math.max(0, diagnosticsViewCount - 1);
			if (!diagnosticsViewCount) {
				clearScheduledDiagnosticsUpdated();
			}
		}
	},
);

function lspLinterSource(view: EditorView): Diagnostic[] {
	const stored = view.state.field(lspPublishedDiagnostics);
	const diagnostics: Diagnostic[] = [];
	for (const [client, items] of stored) {
		const plugin = LSPPlugin.get(view, client);
		if (plugin?.featureEnabled("diagnostics")) diagnostics.push(...items);
	}
	return diagnostics;
}

export function lspDiagnosticsClientExtension(): {
	clientCapabilities: Record<string, unknown>;
	notificationHandlers: Record<
		string,
		(client: LSPClient, params: unknown) => boolean
	>;
} {
	return {
		clientCapabilities: {
			textDocument: {
				publishDiagnostics: {
					relatedInformation: true,
					codeDescriptionSupport: true,
					dataSupport: true,
					versionSupport: true,
				},
				diagnostic: {
					dynamicRegistration: false,
					relatedDocumentSupport: false,
				},
			},
			workspace: {
				diagnostics: {
					refreshSupport: true,
				},
			},
		},
		notificationHandlers: {
			"textDocument/publishDiagnostics": (
				client: LSPClient,
				rawParams: unknown,
			): boolean => {
				const params = rawParams as PublishDiagnosticsParams;
				applyDiagnostics(
					client,
					params.uri,
					params.version,
					params.diagnostics,
				);
				return true;
			},
			"workspace/diagnostic/refresh": (client: LSPClient): boolean => {
				schedulePullDiagnosticsForOpenFiles(client);
				return true;
			},
		},
	};
}

export function lspDiagnosticsUiExtension(includeGutter = true): Extension[] {
	const diagnosticsMarkerFilter = isCoarsePointerDevice()
		? () => []
		: undefined;
	const diagnosticsTooltipFilter = isCoarsePointerDevice()
		? () => []
		: undefined;
	const extensions: Extension[] = [
		diagnosticsLifecyclePlugin,
		lspPublishedDiagnostics,
		linter(lspLinterSource, {
			needsRefresh(update) {
				return update.transactions.some((tr) =>
					tr.effects.some((effect) => effect.is(setPublishedDiagnostics)),
				);
			},
			markerFilter: diagnosticsMarkerFilter,
			tooltipFilter: diagnosticsTooltipFilter,
			// keep panel closed by default
			autoPanel: false,
		}),
	];
	if (includeGutter) {
		extensions.splice(1, 0, lintGutter());
	}
	return extensions;
}

interface DiagnosticsExtension {
	clientCapabilities: Record<string, unknown>;
	notificationHandlers: Record<
		string,
		(client: LSPClient, params: unknown) => boolean
	>;
	editorExtension: Extension[];
}

export function lspDiagnosticsExtension(
	includeGutter = true,
): DiagnosticsExtension {
	return {
		...lspDiagnosticsClientExtension(),
		editorExtension: lspDiagnosticsUiExtension(includeGutter),
	};
}

export default lspDiagnosticsExtension;

export function clearDiagnosticsEffect(
	client?: LSPClient,
): StateEffect<PublishedDiagnosticsUpdate> {
	return setPublishedDiagnostics.of(
		client ? { client, diagnostics: [] } : { clearAll: true },
	);
}

export function getLspDiagnostics(state: EditorState | null): LspDiagnostic[] {
	if (!state || typeof state.field !== "function") return [];
	try {
		const stored = state.field(lspPublishedDiagnostics, false);
		if (!stored) return [];
		return Array.from(stored.values()).flatMap((diagnostics) =>
			diagnostics.map((diagnostic) => ({ ...diagnostic })),
		);
	} catch (_) {
		return [];
	}
}
