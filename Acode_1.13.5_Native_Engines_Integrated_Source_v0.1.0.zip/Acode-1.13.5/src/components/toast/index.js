import "./style.scss";
import { animate } from "motion";

/**@type {Array<HTMLElement>} */
const toastQueue = [];

/**
 * Show a toast message
 * @param {string|HTMLElement} message
 * @param {number|false} [duration=0]
 * @param {string} [bgColor]
 * @param {string} [color]
 */
export default function toast(message, duration = 0, bgColor, color) {
	const $oldToast = tag.get("#toast");
	const $toast = (
		<div
			id="toast"
			attr-clickable={typeof duration !== "number"}
			style={{ backgroundColor: bgColor, color }}
		>
			<span className="message">{message}</span>
			{duration === false ? (
				<button
					className="icon clearclose"
					onclick={() => $toast.hide()}
				></button>
			) : (
				""
			)}
		</div>
	);

	Object.defineProperties($toast, {
		hide: {
			value() {
				animate(
					this,
					{ opacity: 0, transform: "translateY(15px) scale(0.95)" },
					{ duration: 0.25, ease: "easeIn" },
				).then(() => {
					this.remove();
					const $toast = toastQueue.splice(0, 1)[0];
					if ($toast) $toast.show();
				});
			},
		},
		show: {
			value() {
				app.append(this);
				this.style.opacity = "0";
				this.style.transform = "translateY(20px) scale(0.95)";
				animate(
					this,
					{ opacity: 1, transform: "translateY(0) scale(1)" },
					{ type: "spring", stiffness: 300, damping: 25 },
				);

				if (typeof duration === "number") {
					setTimeout(() => {
						this.hide();
					}, duration || 3000);
				}
			},
		},
	});

	if (!$oldToast) {
		$toast.show();
	} else {
		toastQueue.push($toast);
	}
}

toast.hide = () => {
	const $toast = tag.get("#toast");
	if ($toast) $toast.hide();
};
