# D.T.P Build 1.00.13 — Validation Report

**Status: Candidate — real Acode device acceptance pending**

## Automated results

| Suite | Result |
|---|---:|
| Inherited expression/front-end engine suite + 4 typedef regression cases | **94/94 PASS** |
| New shared semantic graph suite | **26/26 PASS** |
| Current mocked Acode provider/lifecycle integration | **19/19 PASS** |
| Historical engine suites, Builds 1.00.01–1.00.12 | **631/631 PASS** |
| Compatible historical lifecycle mock suites | **54/54 PASS** |
| `node --check main.js` | PASS |
| `plugin.json` JSON parse and version match | PASS |
| Manifest-declared files present | PASS |
| ZIP root layout | PASS |
| ZIP CRC integrity | PASS |

The historical lifecycle mock suites from Builds 1.00.06–1.00.08 were not counted: they assert an earlier CodeMirror extension shape that predates the combined completion/lint extension used by the current builds. The current Build 1.00.13 lifecycle suite validates that current path instead.

## What the graph tests cover
- Relative import and export edges, reverse dependents, `part` relationships and package URI resolution.
- Cycle-safe dependency traversal.
- Affected-dependent closure after dependency edits, additions and removals.
- Package configuration retargeting without source reparsing.
- Unchanged AST identity reuse and changed-document-only parse/re-analysis.
- Bounded document retention and cleanup.
- Symbol definitions and same-document identifier references.

## Integration results
The mocked live provider resolves members from an imported open Dart document and then observes an edit to that dependency. The completion result updates from the old member set to the new one without reloading the active document. This verifies the application-level wiring in the test harness, not Android Acode behavior.

## Measured catalog inventory (not an SDK coverage percentage)
The current offline catalog contains six curated non-core SDK libraries with approximately **54 catalog classes, 291 class-member entries, 35 top-level function entries and 22 constant entries**. Core language/member tables are maintained separately. These counts describe this extension's catalog only; they are not a percentage of all Dart SDK APIs.

## Product coverage estimates
These are engineering estimates, not compiler-conformance percentages or unit-test pass rates:
- **Dart language/API breadth: approximately 30–35%.** The front end covers a substantial subset of common declarations, scopes, expressions, records, selected patterns, imports and six curated SDK libraries; the grammar and SDK indexes remain partial, and Flutter framework coverage is not yet included.
- **IntelliSense semantic depth: approximately 45–50%.** Local type inference, nullability/flow approximations, generic substitution, open-document imports, expression AST inference and dependency-aware semantic records exist; overload resolution and compiler-grade type checking remain incomplete.
- **Overall toolkit progress toward a full Dart/Flutter IDE: approximately 25–30%.** Full Dart Analyzer/LSP integration, complete SDK indexing, Flutter analysis, formatter/refactoring, closed-file project indexing and debugger/tooling are still major outstanding areas.

This is the first build where these three product estimates are being recorded using an explicit, conservative scope. Earlier builds do not have a sufficiently consistent scoring baseline for a trustworthy percentage-delta claim. Build 1.00.13 primarily improves semantic infrastructure; it does not pretend that the catalog or grammar breadth rose materially.

## Device acceptance boundary
Automated tests cannot validate actual Acode tab/file lifecycle, Android IME behavior, editor refresh timing, or real CodeMirror completion rendering. Complete `BUILD_1_00_13_ACODE_TESTS_FA.txt` on the target device before marking this build Stable.
