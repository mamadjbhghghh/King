const fs = require('fs');
const vm = require('vm');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, 'main.js'), 'utf8');
const window = { __ACODE_AUTOCOMPLETE_AI_TESTING__: true, acode: { setPluginInit(){}, setPluginUnmount(){} }, editorManager: {} };
const document = { addEventListener(){}, removeEventListener(){}, createElement(){ return { style:{}, setAttribute(){}, appendChild(){}, classList:{ add(){}, remove(){} } }; }, body:{ appendChild(){}, removeChild(){} }, head:{ appendChild(){} } };
const storage = {};
const sandbox = { window, document, console, setTimeout, clearTimeout, setInterval, clearInterval, URL, Blob, Promise, Map, Set, WeakMap, WeakSet, Intl, Date, Math, JSON, Object, Array, String, Number, Boolean, RegExp, Error, TypeError, parseInt, isNaN, performance:{ now:()=>0 }, navigator:{ userAgent:'node' }, localStorage:{ getItem(k){ return storage[k] || null; }, setItem(k,v){ storage[k]=v; }, removeItem(k){ delete storage[k]; } }, requestAnimationFrame(){ return 0; }, cancelAnimationFrame(){} };
vm.createContext(sandbox); vm.runInContext(source, sandbox, { timeout: 30000 });
const api = window.__acodeAutocompleteAITest;
const ai = new api.AutocompleteAI();
let pass=0, fail=0;
function check(name, ok, detail='') { if(ok) pass++; else fail++; console.log(`${ok?'PASS':'FAIL'} ${name}${detail ? ` — ${detail}`:''}`); }
function stateFor(text){ const doc={ toString(){return text;}, lineAt(pos){ const from=text.lastIndexOf('\n',Math.max(0,pos-1))+1; const next=text.indexOf('\n',pos); return {from,to:next<0?text.length:next,number:text.slice(0,from).split('\n').length}; } }; return {doc}; }
function contextFor(text, file='/project/main.py', pos=text.length){ const state=stateFor(text); const activeFile={type:'editor',filename:path.basename(file),uri:file,path:file,session:state}; window.editorManager={editor:{state},activeFile,files:[activeFile],panes:[]}; return {state, context:ai.context({state,pos})}; }
function applyCandidate(text, wantedLabel, file='/project/main.py', pos=text.length, mutate=null){
  const {state,context}=contextFor(text,file,pos);
  const originalCandidates=ai.candidates;
  if(mutate) ai.candidates=function(c){ const items=originalCandidates.call(this,c); mutate(items); return items; };
  try {
    const result=ai.complete({state,pos});
    const option=result?.options?.find(item=>item.label===wantedLabel || item.label.startsWith(wantedLabel));
    if(!option) return {result,option:null,transaction:null,state,context};
    let transaction=null;
    const view={state,dispatch(tr){transaction=tr;}};
    ai.installedViews.add(view);
    option.apply(view,option,result.from,result.to);
    ai.installedViews.delete(view);
    return {result,option,transaction,state,context};
  } finally { ai.candidates=originalCandidates; }
}

// Test 1: active-file recent choice must outrank generic statement-start keywords.
let {state,context}=contextFor('p','/project/recent.py');
const print = ai.candidates(context).find(x=>x.matchLabel==='print');
const now=Date.now();
ai.fileUsage={'/project/recent.py':{print:now-1000}};
let ordered=ai.candidates(context).map(x=>x.matchLabel);
check('recently used print is promoted above pass',ordered.indexOf('print')>=0 && ordered.indexOf('pass')>=0 && ordered.indexOf('print')<ordered.indexOf('pass'),ordered.slice(0,8).join(', '));

// Test 2: most recently used candidate comes first, not merely any previously used one.
ai.fileUsage={'/project/recent.py':{print:now-5000,pow:now-500}};
ordered=ai.candidates(context).map(x=>x.matchLabel);
check('newer file-local choice outranks older file-local choice',ordered.indexOf('pow')<ordered.indexOf('print'),ordered.slice(0,8).join(', '));

// Test 3: usage ordering is file-scoped and does not leak between files.
ai.fileUsage={
  '/project/one.py':{print:now-500,pow:now-5000},
  '/project/two.py':{print:now-5000,pow:now-500}
};
let one=contextFor('p','/project/one.py');
const oneOrder=ai.candidates(one.context).map(x=>x.matchLabel);
let two=contextFor('p','/project/two.py');
const twoOrder=ai.candidates(two.context).map(x=>x.matchLabel);
check('each file keeps its own recent ranking',oneOrder.indexOf('print')<oneOrder.indexOf('pow') && twoOrder.indexOf('pow')<twoOrder.indexOf('print'),`one=${oneOrder.slice(0,4).join(',')}; two=${twoOrder.slice(0,4).join(',')}`);

// Test 4: selected built-in is inserted with balanced call parentheses and caret inside.
ai.fileUsage={};
let applied=applyCandidate('p','print()');
check('print completion inserts print() with caret inside call',applied.transaction?.changes?.insert==='print()' && applied.transaction?.selection?.anchor===6,JSON.stringify(applied.transaction));

// Test 5: even a legacy/incorrect bare callable candidate is normalized on apply.
applied=applyCandidate('p','print', '/project/main.py', 1, items=>{ const p=items.find(x=>x.matchLabel==='print'); if(p){p.label='print';p.insertText='print';p.cursor=null;} });
check('bare print candidate is repaired at selection time',applied.transaction?.changes?.insert==='print()' && applied.transaction?.selection?.anchor===6,JSON.stringify(applied.transaction));

// Test 5b: a real completion acceptance persists global and per-file recency.
ai.fileUsage={};
ai.history={};
applyCandidate('p','print()','/project/accepted.py');
const acceptedTimestamp=Number(ai.fileUsage['/project/accepted.py']?.print)||0;
const acceptedHistory=Object.values(ai.history).some(item=>(item.accepted||0)>0 && (item.last||0)>0);
check('accepted completion persists per-file and global recency',acceptedTimestamp>0 && acceptedHistory,String(acceptedTimestamp));

// Test 6: user-defined Python functions get call parentheses.
const fnSource='def process(value):\n    return value\n\npro';
applied=applyCandidate(fnSource,'process(');
check('user-defined function completion inserts a call',applied.transaction?.changes?.insert==='process()' && applied.transaction?.selection?.anchor===applied.transaction?.changes?.from+8,JSON.stringify(applied.transaction));

// Test 6b: other common built-ins use the same call insertion contract.
for (const [prefix,name] of [['po','pow'],['le','len'],['in','input'],['ra','range']]) {
  applied=applyCandidate(prefix,`${name}()`);
  check(`${name} completion inserts balanced parentheses`,applied.transaction?.changes?.insert===`${name}()` && applied.transaction?.selection?.anchor===applied.transaction?.changes?.from+name.length+1,JSON.stringify(applied.transaction));
}

// Test 6c: user-defined classes are constructor calls in expression position.
applied=applyCandidate('class Player: pass\n\nPla','Player()');
check('class constructor completion inserts a call',applied.transaction?.changes?.insert==='Player()' && applied.transaction?.selection?.anchor===applied.transaction?.changes?.from+7,JSON.stringify(applied.transaction));

// Test 7: choosing a callable where an opening parenthesis already exists must not duplicate it.
const parenSource='p(';
applied=applyCandidate(parenSource,'print()', '/project/main.py', 1);
check('existing opening parenthesis is reused',applied.transaction?.changes?.insert==='print' && applied.transaction?.changes?.to===1,JSON.stringify(applied.transaction));

// Test 8: imports and decorators remain bare-name contexts.
let imported=contextFor('from builtins import p');
let importedCandidate=ai.candidates(imported.context).find(x=>x.matchLabel==='print');
check('callable names in import context stay bare',!!importedCandidate && importedCandidate.insertText==='print' && importedCandidate.cursor===null,JSON.stringify(importedCandidate&&{label:importedCandidate.label,insertText:importedCandidate.insertText,cursor:importedCandidate.cursor}));
let decorated=contextFor('@pro');
let decoratedCandidate=ai.candidates(decorated.context).find(x=>x.matchLabel==='property');
check('decorator completion stays bare',!!decoratedCandidate && decoratedCandidate.insertText==='property' && decoratedCandidate.cursor===null,JSON.stringify(decoratedCandidate&&{label:decoratedCandidate.label,insertText:decoratedCandidate.insertText,cursor:decoratedCandidate.cursor}));

// Test 9: type annotations and class bases are not rewritten into calls.
let annotation=contextFor('value: P');
const annotationCandidate={kind:'defined',type:'function',matchLabel:'Player',label:'Player',insertText:'Player'};
check('type annotation context is recognized',ai.isPythonTypeAnnotationPosition({...annotation.context,lineBeforeWord:'value:'}));
check('type annotation does not force call parentheses',!ai.isPythonCallableCompletion(annotationCandidate,{...annotation.context,lineBeforeWord:'value:'}));
check('class-base context is recognized as a bare-name position',ai.isPythonTypeAnnotationPosition({...annotation.context,lineBeforeWord:'class Child(Base'}));
check('class-base completion does not force call parentheses',!ai.isPythonCallableCompletion(annotationCandidate,{...annotation.context,lineBeforeWord:'class Child(Base'}));

console.log(`SUMMARY ${pass}/${pass+fail} PASS; ${fail} FAIL`);
if(fail) process.exitCode=1;
