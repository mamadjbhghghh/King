const fs = require('fs');
const vm = require('vm');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, 'main.js'), 'utf8');
const window = { __ACODE_AUTOCOMPLETE_AI_TESTING__: true, acode: { setPluginInit() {}, setPluginUnmount() {} }, editorManager: { activeFile: { filename: '/project/main.py' }, files: [] } };
const listeners = new Map();
const document = { visibilityState: 'visible', addEventListener(n, f) { listeners.set(n, f); }, removeEventListener(n) { listeners.delete(n); }, createElement() { return { style: {}, setAttribute() {}, appendChild() {}, classList: { add() {}, remove() {} } }; }, body: { appendChild() {}, removeChild() {} }, head: { appendChild() {} } };
const sandbox = { window, document, console, setTimeout, clearTimeout, setInterval, clearInterval, URL, Blob, Promise, Map, Set, WeakMap, WeakSet, Intl, Date, Math, JSON, Object, Array, String, Number, Boolean, RegExp, Error, TypeError, parseInt, isNaN, performance: { now: () => 0 }, navigator: { userAgent: 'Android WebView' }, localStorage: { getItem() { return null; }, setItem() {}, removeItem() {} }, requestAnimationFrame() { return 1; }, cancelAnimationFrame() {} };
vm.createContext(sandbox); vm.runInContext(source, sandbox, { timeout: 30000 });
const api = window.__acodeAutocompleteAITest;
if (!api?.AutocompleteAI || !api?.classifyPythonGhostExpressionContext || !api?.buildSemanticGhostPreviewCandidate) throw new Error('Integrated Ghost test bridge unavailable');
let pass = 0, fail = 0;
function check(name, condition, detail = '') { if (condition) pass++; else fail++; console.log(`${condition ? 'PASS' : 'FAIL'} ${name}${detail ? '; ' + detail : ''}`); }
const contexts = [
  ['assignment', 'result = user.gr', 'assignment-value'],
  ['return', 'return user.gr', 'return-value'],
  ['condition', 'if user.re', 'condition'],
  ['call argument', 'consume(user.gr', 'call-argument'],
  ['collection element', '[user.gr', 'collection-element'],
  ['annotation suppression', 'user: User.gr', 'type-annotation']
];
for (const [label, line, expected] of contexts) check(`context classifier: ${label}`, api.classifyPythonGhostExpressionContext(line) === expected, api.classifyPythonGhostExpressionContext(line));
check('semantic candidate builder is exposed for integrated pipeline', typeof api.buildSemanticGhostPreviewCandidate === 'function');
const ai = new api.AutocompleteAI(); ai.config.enabled = true; ai.config.inlineGhostText = true;
const docText = 'class User:\n    def greet(self):\n        pass\nuser = User()\nresult = user.gr';
const doc = { length: docText.length, toString: () => docText, lineAt(p) { const from = docText.lastIndexOf('\n', Math.max(0, p - 1)) + 1; const e = docText.indexOf('\n', p); return { from, to: e < 0 ? docText.length : e }; } };
const state = { doc, selection: { main: { head: docText.length, empty: true } } };
const view = { state, hasFocus: true, dom: { isConnected: true }, coordsAtPos() { return { left: 10, top: 20 }; } };
ai.activeGhostView = view;
let session = ai.computeGhostSession(state); if (session) session.doc = doc; ai.ghostSessions.set(view, session);
check('integrated semantic preview starts with expected suffix', session?.text === 'eet()', JSON.stringify(session));
ai.ghostComposing.add(view); ai.handleGhostUpdate(view, { state, docChanged: true });
check('IME composition invalidates semantic preview', ai.ghostSessions.get(view) === null);
ai.refreshGhostForView(view, true);
check('forced semantic refresh remains suppressed during composition', ai.ghostSessions.get(view) === null);
ai.ghostComposing.delete(view); ai.refreshGhostForView(view, true);
check('semantic preview recovers after composition', ai.ghostSessions.get(view)?.text === 'eet()');
ai.ghostDismissed.set(view, { doc, pos: state.selection.main.head }); ai.handleGhostUpdate(view, { state, selectionSet: true });
check('dismissal state survives integrated lifecycle update', ai.ghostSessions.get(view) === null);
check('composition listener remains registered', listeners.has('compositionstart') || source.includes('document.addEventListener?.("compositionstart"'));
check('visibility lifecycle listener remains registered', source.includes('document.addEventListener?.("visibilitychange"'));
ai.destroy();
console.log(`SUMMARY ${pass}/${pass + fail} PASS; ${fail} FAIL`); if (fail) process.exitCode = 1;
