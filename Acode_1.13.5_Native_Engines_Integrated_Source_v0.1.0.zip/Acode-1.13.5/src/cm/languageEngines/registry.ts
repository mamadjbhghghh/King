/**
 * Native language-engine registry for Acode.
 *
 * Engines are deliberately isolated behind a small host contract. A language
 * implementation may provide completion, diagnostics, formatting and lifecycle
 * hooks without owning CodeMirror's global autocomplete configuration.
 */
export type LanguageEngineContext = {
  view: unknown;
  path: string;
  language: string;
};

export type LanguageEngine = {
  id: string;
  languages: readonly string[];
  extensions: readonly string[];
  priority?: number;
  activate?: () => void | Promise<void>;
  deactivate?: () => void | Promise<void>;
  complete?: (context: LanguageEngineContext & Record<string, unknown>) => unknown;
  diagnose?: (context: LanguageEngineContext & Record<string, unknown>) => unknown;
  format?: (context: LanguageEngineContext & Record<string, unknown>) => unknown;
};

function normalize(value: unknown): string {
  return String(value ?? "").trim().toLowerCase();
}

function normalizeExtension(value: unknown): string {
  const extension = normalize(value);
  if (!extension) return "";
  return extension.startsWith(".") ? extension : `.${extension}`;
}

/** Owns engine registration and deterministic language/path routing. */
export class LanguageEngineRegistry {
  #engines = new Map<string, LanguageEngine>();
  #active = new Set<string>();

  register(engine: LanguageEngine): () => void {
    const id = normalize(engine?.id);
    if (!id) throw new TypeError("Language engine requires a non-empty id");
    if (this.#engines.has(id)) throw new Error(`Language engine already registered: ${id}`);
    if (!Array.isArray(engine.languages) || !Array.isArray(engine.extensions)) {
      throw new TypeError(`Language engine ${id} requires languages and extensions arrays`);
    }
    const normalized: LanguageEngine = Object.freeze({
      ...engine,
      id,
      languages: Object.freeze([...new Set(engine.languages.map(normalize).filter(Boolean))]),
      extensions: Object.freeze([...new Set(engine.extensions.map(normalizeExtension).filter(Boolean))]),
      priority: Number.isFinite(engine.priority) ? Number(engine.priority) : 0,
    });
    this.#engines.set(id, normalized);
    return () => this.unregister(id);
  }

  unregister(id: string): boolean {
    const key = normalize(id);
    if (!this.#engines.has(key)) return false;
    const engine = this.#engines.get(key)!;
    this.#engines.delete(key);
    const wasActive = this.#active.delete(key);
    if (wasActive) {
      try {
        const result = engine.deactivate?.();
        if (result && typeof (result as Promise<void>).catch === "function") {
          void (result as Promise<void>).catch((error) => console.warn(`Failed to deactivate ${key}`, error));
        }
      } catch (error) { console.warn(`Failed to deactivate ${key}`, error); }
    }
    return true;
  }

  async activate(id: string): Promise<boolean> {
    const key = normalize(id);
    const engine = this.#engines.get(key);
    if (!engine) return false;
    if (this.#active.has(key)) return true;
    await engine.activate?.();
    this.#active.add(key);
    return true;
  }

  async deactivate(id: string): Promise<boolean> {
    const key = normalize(id);
    const engine = this.#engines.get(key);
    if (!engine) return false;
    if (this.#active.has(key)) await engine.deactivate?.();
    this.#active.delete(key);
    return true;
  }

  resolve(path: string, language = ""): LanguageEngine | null {
    const normalizedLanguage = normalize(language);
    const cleanPath = String(path ?? "").split(/[?#]/u, 1)[0].toLowerCase();
    const extension = cleanPath.slice(cleanPath.lastIndexOf("."));
    const engines = [...this.#engines.values()];
    const languageMatches = normalizedLanguage
      ? engines.filter((engine) => engine.languages.includes(normalizedLanguage))
      : [];
    const candidates = languageMatches.length
      ? languageMatches
      : engines.filter((engine) => extension && engine.extensions.includes(extension));
    candidates.sort((a, b) => (b.priority || 0) - (a.priority || 0) || a.id.localeCompare(b.id));
    return candidates[0] || null;
  }

  /** Resolve and invoke exactly one engine for the current document. */
  complete(context: LanguageEngineContext & Record<string, unknown>): unknown {
    const engine = this.resolve(context.path, context.language);
    if (!engine || !this.#active.has(engine.id) || typeof engine.complete !== "function") return null;
    return engine.complete(context);
  }

  /** Completion callbacks in deterministic priority order (useful for host composition). */
  getCompletionSources() {
    return [...this.#engines.values()]
      .filter((engine) => this.#active.has(engine.id) && typeof engine.complete === "function")
      .sort((a, b) => (b.priority || 0) - (a.priority || 0))
      .map((engine) => engine.complete!);
  }

  list() {
    return [...this.#engines.values()].map((engine) => Object.freeze({
      id: engine.id,
      languages: engine.languages,
      extensions: engine.extensions,
      priority: engine.priority || 0,
      active: this.#active.has(engine.id),
    }));
  }

  async dispose() {
    const ids = [...this.#engines.keys()];
    for (const id of ids.reverse()) await this.deactivate(id);
    this.#engines.clear();
    this.#active.clear();
  }
}

const languageEngineRegistry = new LanguageEngineRegistry();
export default languageEngineRegistry;
