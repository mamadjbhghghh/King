const fs = require('fs');
const vm = require('vm');
const path = require('path');

class FakeNode {
  constructor(tagName = 'div', options = {}) {
    this.tagName = String(tagName).toUpperCase();
    this.className = options.className || '';
    this.textContent = options.textContent || '';
    this.innerHTML = '';
    this.style = {};
    this.dataset = {};
    this.children = [];
    this.parentNode = null;
    this.isConnected = false;
    this.listeners = new Map();
    this.attributes = new Map();
    this.classList = {
      add: (...xs) => { const set = new Set(String(this.className).split(/\s+/).filter(Boolean)); xs.forEach(x => set.add(x)); this.className = [...set].join(' '); },
      remove: (...xs) => { const set = new Set(String(this.className).split(/\s+/).filter(Boolean)); xs.forEach(x => set.delete(x)); this.className = [...set].join(' '); },
      contains: x => String(this.className).split(/\s+/).includes(x),
      toggle: (x, force) => { const has = this.classList.contains(x); const next = force === undefined ? !has : Boolean(force); next ? this.classList.add(x) : this.classList.remove(x); return next; }
    };
    if (options.attr) for (const [k, v] of Object.entries(options.attr)) this.setAttribute(k, v);
    if (options.children) this.append(...options.children);
    if (options.onclick) this.onclick = options.onclick;
    if (options.onkeydown) this.onkeydown = options.onkeydown;
    if (options.oninput) this.oninput = options.oninput;
  }
  append(...nodes) { for (const n of nodes) { if (!n) continue; n.parentNode = this; n.isConnected = this.isConnected; this.children.push(n); } }
  appendChild(node) { this.append(node); return node; }
  remove() { this.isConnected = false; if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(x => x !== this); }
  setAttribute(k, v) { this.attributes.set(k, String(v)); }
  getAttribute(k) { return this.attributes.get(k) || null; }
  addEventListener(k, fn) { const list = this.listeners.get(k) || []; list.push(fn); this.listeners.set(k, list); }
  removeEventListener(k, fn) { this.listeners.set(k, (this.listeners.get(k) || []).filter(x => x !== fn)); }
  querySelector(selector) {
    if (selector === 'textarea' && this.tagName === 'TEXTAREA') return this;
    for (const c of this.children) {
      if (selector === 'textarea' && c.tagName === 'TEXTAREA') return c;
      const found = c.querySelector?.(selector);
      if (found) return found;
    }
    return null;
  }
  focus() { this.focused = true; }
}

const registered = new Map();
const workerInstances = [];
let holdInit = false;
class FakeWorker {
  constructor(url, options) { this.url = url; this.options = options; this.terminated = false; workerInstances.push(this); }
  postMessage(message) {
    setTimeout(() => {
      if (this.terminated) return;
      if (message.action === 'init') {
        if (!holdInit) this.onmessage?.({ data: { action: 'init', success: true } });
      } else if (message.action === 'run') {
        this.onmessage?.({ data: { action: 'run', success: true, output: 'mock-run-complete' } });
      }
    }, 0);
  }
  terminate() { this.terminated = true; }
}
function makePage() {
  const pageRoot = new FakeNode('div');
  const pageHeader = new FakeNode('header');
  return {
    id: '', header: pageHeader, classList: pageRoot.classList, onhide: () => {},
    get isConnected() { return pageRoot.isConnected; },
    get(selector) { return selector === '.main' ? pageRoot.children.find(x => x.className === 'main') || null : pageRoot.querySelector(selector); },
    append(...nodes) { pageRoot.append(...nodes); },
    settitle(value) { this.title = value; },
    show() { pageRoot.isConnected = true; pageRoot.children.forEach(x => x.isConnected = true); },
    hide() { const was = pageRoot.isConnected; pageRoot.isConnected = false; if (was) this.onhide?.(); },
    finalizeHeaderOrder() {},
    disposeStyle() {}
  };
}
const document = {
  head: new FakeNode('head'),
  body: new FakeNode('body'),
  createElement: name => new FakeNode(name),
  querySelector: () => null
};
const editorManager = {
  activeFile: null,
  editor: { getValue: () => 'print("hello")' },
  on(name, callback) { registered.set(name, callback); },
  off(name, callback) { if (registered.get(name) === callback) registered.delete(name); }
};
const context = {
  window: {}, document, console, setTimeout, clearTimeout, Promise, Map, Set, WeakMap, WeakSet,
  URL, Blob, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, WebAssembly, Worker: FakeWorker,
  navigator: { userAgent: 'Acode test harness' },
  localStorage: { getItem: () => null, setItem() {} }, editorManager,
  root: { get: () => ({ get: () => null, insertBefore() {} }) },
  strings: { 'loading...': 'loading…' },
  tag: (name, options = {}) => new FakeNode(name, options),
  getComputedStyle: () => ({ paddingLeft: '0px', paddingRight: '0px' })
};
vm.createContext(context);
const bridge = fs.readFileSync(path.join(__dirname, 'python-runtime/runtime-main.js'), 'utf8');
vm.runInContext(bridge, context, { timeout: 10000 });
const factory = context.window.__ACODE_PTP_PYTHON_RUNTIME_FACTORY__;
if (typeof factory !== 'function') throw new Error('Runtime factory was not exposed');
let pass = 0, fail = 0;
function check(name, ok, detail = '') {
  if (ok) pass++; else fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
}
const options = () => ({ cacheFile: { async writeFile() { return true; } }, cacheFileUrl: 'file:///ptp-cache/stdin' });
(async () => {
  const page = makePage();
  const handle = factory();
  check('factory exposes runtime run command', typeof handle.runtime.run === 'function');
  check('upstream bundle does not register a second plugin lifecycle', typeof context.window.acode === 'undefined');
  let initialized = false;
  try { initialized = await handle.init('file:///ptp/python-runtime/', page, options()); }
  catch (error) { console.error(error); }
  check('mock Acode init reaches ready worker handshake', initialized && workerInstances.length >= 1);
  check('worker URL resolves inside P.T.P runtime directory', workerInstances[0]?.url === 'file:///ptp/python-runtime/worker.js');
  let ran = false;
  try { await handle.runtime.run(); ran = true; } catch (error) { console.error(error); }
  check('runtime run path completes against mock Worker protocol', ran);
  check('editor event callbacks are registered once', registered.size === 2);
  page.hide();
  handle.destroy();
  page.disposeStyle();
  check('destroy unregisters exact editor callback identities', registered.size === 0);
  check('close/unmount cleanup terminates all created workers', workerInstances.every(worker => worker.terminated));

  // Verify cancellation does not wait for the 30-second worker timeout or leave the worker alive.
  holdInit = true;
  const page2 = makePage();
  const handle2 = factory();
  const pendingInit = handle2.init('file:///ptp/python-runtime/', page2, options()).then(
    () => ({ resolved: true }),
    error => ({ resolved: false, message: String(error?.message || error) })
  );
  await new Promise(resolve => setTimeout(resolve, 5));
  handle2.destroy();
  const cancellation = await Promise.race([
    pendingInit,
    new Promise(resolve => setTimeout(() => resolve({ timeout: true }), 250))
  ]);
  check('plugin unmount cancels pending worker initialization promptly', cancellation?.resolved === false && /cancelled/u.test(cancellation.message || ''));
  check('cancelled initialization terminates its worker', workerInstances.slice(2).every(worker => worker.terminated));
  check('onhide chaining tolerates a nullable page callback', bridge.includes('typeof A.onhide==="function"?A.onhide:()=>{}'));
  console.log(`SUMMARY ${pass}/${pass + fail} PASS; ${fail} FAIL`);
  if (fail) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
