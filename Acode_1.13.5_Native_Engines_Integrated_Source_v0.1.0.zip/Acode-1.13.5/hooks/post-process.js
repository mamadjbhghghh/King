/* eslint-disable no-console */
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

const buildFilePath = path.resolve(__dirname, '../build.json');
const copyToPath = path.resolve(__dirname, '../platforms/android/build.json');
const gradleFilePath = path.resolve(__dirname, '../build-extras.gradle');
const androidGradleFilePath = path.resolve(
  __dirname,
  '../platforms/android/app/build-extras.gradle'
);
const resPath = path.resolve(__dirname, '../platforms/android/app/src/main/res/');
const localResPath = path.resolve(__dirname, '../res/android/');

if (
  !fs.existsSync(copyToPath)
  && fs.existsSync(buildFilePath)
) fs.copyFileSync(buildFilePath, copyToPath);

if (fs.existsSync(androidGradleFilePath)) fs.unlinkSync(androidGradleFilePath);
fs.copyFileSync(gradleFilePath, androidGradleFilePath);

// Cordova Android 15 generates `cdv_*` resources and version-qualified value
// directories that are required later in the build. Keep the generated tree and
// only overlay this project's custom resources on top of it.
copyDirRecursively(localResPath, resPath);
// Cordova can retain plugin Java from an earlier install during prepare.
// Keep the System plugin's icon map in sync with the launcher resources.
copyDirRecursively(
  path.resolve(__dirname, '../src/plugins/system/android'),
  path.resolve(__dirname, '../platforms/android/app/src/main/java')
);
enableLegacyJni();
enableStaticContext();
disableSplashFadeOnRealmeAndroid13();
removeLegacyKeyboardWorkaround();
patchTargetSdkVersion();
stripLauncherFilterFromMainActivity();

function getPackageName() {
  const configPath = path.resolve(__dirname, '../config.xml');
  if (!fs.existsSync(configPath)) {
    console.warn('[Cordova Hook] ⚠️ config.xml not found at', configPath);
    throw new Error(`config.xml is missing at ${configPath}`);
  }
  const content = fs.readFileSync(configPath, 'utf-8');
  const match = content.match(/id="([^"]+)"/);
  const packageName = match ? match[1] : 'com.foxdebug.acode';
  return packageName;
}


function getTmpDir() {
  const tmpdirEnv = process.env.TMPDIR;

  if (tmpdirEnv) {
    try {
      fs.accessSync(tmpdirEnv, fs.constants.R_OK | fs.constants.W_OK);
      return tmpdirEnv;
    } catch {
      // TMPDIR exists but not accessible
    }
  }

  try {
    fs.accessSync("/tmp", fs.constants.R_OK | fs.constants.W_OK);
    return "/tmp";
  } catch {
    console.log("Error: No usable temporary directory found (TMPDIR or /tmp not accessible).");
    return null;
    // process.exit(1);
  }
}

/**
 * Removes the MAIN/LAUNCHER intent-filter from MainActivity in the generated
 * AndroidManifest. The launcher role is handled by activity-aliases instead
 * (see config.xml), so that switching app icons at runtime only toggles aliases
 * and never disables the running MainActivity component (which would otherwise
 * force-stop/restart the app).
 */
function stripLauncherFilterFromMainActivity() {
  const prefix = execSync('npm prefix').toString().trim();
  const manifestPath = path.join(
    prefix,
    'platforms/android/app/src/main/AndroidManifest.xml'
  );

  if (!fs.existsSync(manifestPath)) {
    console.warn('[Cordova Hook] ⚠️ AndroidManifest.xml not found');
    return;
  }

  let content = fs.readFileSync(manifestPath, 'utf-8');
  const updated = content.replace(
    /(<activity[^>]*\bname="MainActivity"[^>]*>)\s*<intent-filter[^>]*>\s*<action android:name="android\.intent\.action\.MAIN"[^>]*\/>\s*<category android:name="android\.intent\.category\.LAUNCHER"[^>]*\/>\s*<\/intent-filter>/,
    '$1'
  );

  if (updated !== content) {
    fs.writeFileSync(manifestPath, updated, 'utf-8');
    console.log(
      '[Cordova Hook] ✅ Removed launcher intent-filter from MainActivity'
    );
  } else {
    console.log(
      '[Cordova Hook] ✅ Launcher intent-filter already removed, skipping'
    );
  }
}

function patchTargetSdkVersion() {
  const prefix = execSync('npm prefix').toString().trim();
  const gradleFile = path.join(prefix, 'platforms/android/app/build.gradle');

  if (!fs.existsSync(gradleFile)) {
    console.warn('[Cordova Hook] ⚠️ build.gradle not found');
    return;
  }

  let content = fs.readFileSync(gradleFile, 'utf-8');

  const sdkRegex = /targetSdkVersion\s+(cordovaConfig\.SDK_VERSION|\d+)/;

  if (sdkRegex.test(content)) {
    let api = "36";
    const tmp = getTmpDir();
    if (tmp == null) {
      console.warn("---------------------------------------------------------------------------------\n\n\n\n");
      console.warn(`⚠️ fdroid.bool not found`);
      console.warn("⚠️ Fdroid flavour will be built");
      api = "28";
      console.warn("\n\n\n\n---------------------------------------------------------------------------------");
    } else {
      const froidFlag = path.join(getTmpDir(), 'fdroid.bool');

      if (fs.existsSync(froidFlag)) {
        const fdroid = fs.readFileSync(froidFlag, 'utf-8').trim();
        if (fdroid == "true") {
          api = "28";
        }
      } else {
        console.warn("---------------------------------------------------------------------------------\n\n\n\n");
        console.warn(`⚠️ fdroid.bool not found`);
        console.warn("⚠️ Fdroid flavour will be built");
        api = "28";
        console.warn("\n\n\n\n---------------------------------------------------------------------------------");
        //process.exit(1);
      }
    }


    content = content.replace(sdkRegex, 'targetSdkVersion ' + api);
    fs.writeFileSync(gradleFile, content, 'utf-8');
    console.log('[Cordova Hook] ✅ Patched targetSdkVersion to ' + api);
  } else {
    console.warn('[Cordova Hook] ⚠️ targetSdkVersion not found');
  }
}


function enableLegacyJni() {
  const prefix = execSync('npm prefix').toString().trim();
  const gradleFile = path.join(prefix, 'platforms/android/app/build.gradle');

  if (!fs.existsSync(gradleFile)){
    console.warn('[Cordova Hook] ⚠️ build.gradle not found');
     return
  };

  let content = fs.readFileSync(gradleFile, 'utf-8');
  // Check for correct block to avoid duplicate insertion
  if (content.includes('useLegacyPackaging = true')){
    console.log('[Cordova Hook] ✅ Legacy JNI packaging already enabled, skipping');
    return
  };

  // Inject under android block with correct Groovy syntax
  content = content.replace(/android\s*{/, match => {
    return (
      match +
      `
    packagingOptions {
        jniLibs {
            useLegacyPackaging = true
        }
    }`
    );
  });

  fs.writeFileSync(gradleFile, content, 'utf-8');
  console.log('[Cordova Hook] ✅ Enabled legacy JNI packaging');
}

function enableStaticContext() {
  try {
    const prefix = execSync('npm prefix').toString().trim();
    const packageName = getPackageName();
    const mainActivityPath = path.join(
      prefix,
      'platforms/android/app/src/main/java',
      packageName.replace(/\./g, '/'),
      'MainActivity.java'
    );

    if (!fs.existsSync(mainActivityPath)) {
      console.warn('[Cordova Hook] ⚠️ MainActivity.java not found at', mainActivityPath);
      return;
    }

    let content = fs.readFileSync(mainActivityPath, 'utf-8');

    // Skip if fully patched
    if (
      content.includes('WeakReference<Context>') &&
      content.includes('public static Context getContext()') &&
      content.includes('weakContext = new WeakReference<>(this);')
    ) {
      console.log('[Cordova Hook] ✅ Static context already enabled, skipping');
      return;
    }

    // Add missing imports
    if (!content.includes('import java.lang.ref.WeakReference;')) {
      content = content.replace(
        /import org\.apache\.cordova\.\*;/,
        match =>
          match +
          '\nimport android.content.Context;\nimport java.lang.ref.WeakReference;'
      );
    }

    // Inject static field and method into class body
    content = content.replace(
      /public class MainActivity extends CordovaActivity\s*\{/,
      match =>
        match +
        `\n\n    private static WeakReference<Context> weakContext;\n\n` +
        `    public static Context getContext() {\n` +
        `        return weakContext != null ? weakContext.get() : null;\n` +
        `    }\n`
    );

    // Insert weakContext assignment inside onCreate
    content = content.replace(
      /super\.onCreate\(savedInstanceState\);/,
      `super.onCreate(savedInstanceState);\n        weakContext = new WeakReference<>(this);`
    );

    fs.writeFileSync(mainActivityPath, content, 'utf-8');
    console.log('[Cordova Hook] ✅ Enabled static context');
  } catch (err) {
    console.error('[Cordova Hook] ❌ Failed to patch MainActivity:', err.message);
  }
}

function disableSplashFadeOnRealmeAndroid13() {
  try {
    const prefix = execSync('npm prefix').toString().trim();
    const packageName = getPackageName();
    const mainActivityPath = path.join(
      prefix,
      'platforms/android/app/src/main/java',
      packageName.replace(/\./g, '/'),
      'MainActivity.java'
    );

    if (!fs.existsSync(mainActivityPath)) {
      console.warn('[Cordova Hook] ⚠️ MainActivity.java not found at', mainActivityPath);
      return;
    }

    let content = fs.readFileSync(mainActivityPath, 'utf-8');

    if (
      content.includes('hasBrokenRealmeSplashTransfer()') &&
      content.includes('preferences.set("FadeSplashScreen", false);')
    ) {
      console.log('[Cordova Hook] ✅ realme splash workaround already enabled, skipping');
      return;
    }

    if (!content.includes('import android.os.Build;')) {
      content = content.replace(
        /import android\.os\.Bundle;/,
        'import android.os.Build;\nimport android.os.Bundle;'
      );
    }

    content = content.replace(
      /\n\s*@Override\n\s*public void onCreate\(Bundle savedInstanceState\)/,
      `

    private static boolean hasBrokenRealmeSplashTransfer() {
        return Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU
            && ("realme".equalsIgnoreCase(Build.MANUFACTURER)
                || "realme".equalsIgnoreCase(Build.BRAND));
    }

    @Override
    protected void loadConfig() {
        super.loadConfig();

        // Some realme Android 13 builds pass a null SurfaceControl while handing the
        // splash view to an app-provided exit animation. Avoid only that handoff.
        if (hasBrokenRealmeSplashTransfer()) {
            preferences.set("FadeSplashScreen", false);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState)`
    );

    if (!content.includes('preferences.set("FadeSplashScreen", false);')) {
      console.warn('[Cordova Hook] ⚠️ Unable to inject realme splash workaround');
      return;
    }

    fs.writeFileSync(mainActivityPath, content, 'utf-8');
    console.log('[Cordova Hook] ✅ Disabled splash fade on realme Android 13');
  } catch (err) {
    console.error(
      '[Cordova Hook] ❌ Failed to patch realme splash workaround:',
      err.message
    );
  }
}

function removeLegacyKeyboardWorkaround() {
  try {
    const prefix = execSync('npm prefix').toString().trim();
    const packageName = getPackageName();
    const mainActivityPath = path.join(
      prefix,
      'platforms/android/app/src/main/java',
      packageName.replace(/\./g, '/'),
      'MainActivity.java'
    );

    if (!fs.existsSync(mainActivityPath)) {
      return;
    }

    const content = fs.readFileSync(mainActivityPath, 'utf-8');
    const updatedContent = content
      .replace(/\r?\nimport com\.foxdebug\.system\.SoftInputAssist;/, '')
      .replace(/\r?\n\s*private SoftInputAssist softInputAssist;\r?\n/, '\n')
      .replace(
        /\r?\n\s*softInputAssist = new SoftInputAssist\(this\);/,
        ''
      );

    if (updatedContent !== content) {
      fs.writeFileSync(mainActivityPath, updatedContent, 'utf-8');
      console.log('[Cordova Hook] ✅ Removed legacy keyboard workaround');
    }
  } catch (err) {
    console.error(
      '[Cordova Hook] ❌ Failed to remove legacy keyboard workaround:',
      err.message
    );
  }
}

/**
 * Copy directory recursively
 * @param {string} src Source directory
 * @param {string} dest Destination directory
 * @param {string[]} skip Files to not copy
 */
function copyDirRecursively(src, dest, skip = [], currPath = '') {
  const exists = fs.existsSync(src);
  const stats = exists && fs.statSync(src);
  const isDirectory = exists && stats.isDirectory();

  if (!exists) {
    console.log(`File ${src} does not exist`);
    return;
  }

  if (!fs.existsSync(dest) && isDirectory) {
    fs.mkdirSync(dest);
  }

  if (exists && isDirectory) {
    fs.mkdirSync(dest, { recursive: true });
    fs.readdirSync(src).forEach((childItemName) => {
      const relativePath = path.join(currPath, childItemName);
      if (childItemName.startsWith('.')) return;
      if (skip.includes(childItemName) || skip.includes(relativePath)) return;
      copyDirRecursively(
        path.join(src, childItemName),
        path.join(dest, childItemName),
        skip,
        relativePath,
      );
    });
  } else {
    removeConflictingResourceFiles(src, dest);
    fs.copyFileSync(src, dest);

    // log
    const message = `copied: ${path.basename(src)}`;
    console.log('\x1b[32m%s\x1b[0m', message); // green
  }
}

function removeConflictingResourceFiles(src, dest) {
  const parentDir = path.dirname(dest);

  if (!fs.existsSync(parentDir)) {
    return;
  }

  const resourceDirName = path.basename(parentDir);
  if (!resourceDirName.startsWith('mipmap') && !resourceDirName.startsWith('drawable')) {
    return;
  }

  const srcExt = path.extname(src);
  const resourceName = path.basename(src, srcExt);

  for (const existingName of fs.readdirSync(parentDir)) {
    const existingPath = path.join(parentDir, existingName);
    if (existingPath === dest || !fs.statSync(existingPath).isFile()) {
      continue;
    }

    const existingExt = path.extname(existingName);
    const existingResourceName = path.basename(existingName, existingExt);

    if (existingResourceName !== resourceName || existingExt === srcExt) {
      continue;
    }

    fs.rmSync(existingPath);
    console.log('\x1b[31m%s\x1b[0m', `deleted conflicting resource: ${existingName}`);
  }
}
