# Candidate 0.1.0 — Source validation report

## Automated checks completed

- `node --check` passed for `src/cm/nativeLanguageEngines.js`.
- `node --check` passed for the bundled Python, Dart and HTML/CSS engine scripts.
- ZIP CRC/integrity check passed.
- All 1,053 original non-directory files from the supplied Acode 1.13.5 archive are present in the output; only `src/main.js` was modified among original files.
- Original `www/index.html`, `www/icons/` and all existing static assets remain present.
- Engine scripts and their packaged support assets are present in `www/native-language-engines/`.

## Checks not completed

- No dependency installation was performed.
- Rspack/TypeScript/Vitest were not run because the Acode repository's `node_modules` are not installed in this environment.
- Cordova/Gradle/Android APK compilation was not run.
- No Android runtime/device test was performed.

## Result

Source-level packaging and JavaScript syntax checks passed. Compile and Android runtime status remain unverified.
