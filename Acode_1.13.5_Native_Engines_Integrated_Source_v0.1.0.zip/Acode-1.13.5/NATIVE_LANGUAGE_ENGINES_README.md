# Acode 1.13.5 — Native Language Engines Integration Candidate 0.1.0

## What is integrated

This source tree bundles the language-engine implementations from:

- Python Toolkit Pro 3.00 full-integration release candidate (Python completion, semantic analysis, editor intelligence and related P.T.P editor services).
- Dart Toolkit Pro 1.00.13 (Dart completion and semantic graph intelligence).
- HTML/CSS Toolkit Pro 1.00.04 (HTML and CSS completion, snippets, attributes, values and auto-pairing).

The three engine scripts are packaged under `www/native-language-engines/` and started by Acode itself from `src/cm/nativeLanguageEngines.js`. The host registry in `src/cm/languageEngines/registry.ts` owns deterministic engine registration, activation, deactivation and path/language resolution. Acode remains responsible for its editor manager and application lifecycle.

The native bridge deliberately reuses Acode's existing `setPluginInit` / `initPlugin` lifecycle contract for compatibility with the upstream engines. The engines are app-bundled and auto-started; they do not need to be installed as separate plugins. If the standalone versions were previously installed, their active instances are unmounted before the bundled copies are activated.

## Deliberately deferred from the language-engine core

Two optional P.T.P modules are marked `detached` in the bundled source:

- Pyodide Python runtime (execution environment, WASM and standard library payload).
- Material Icons Advanced 858-icon pack.

They are not required for Python IntelliSense and were excluded to avoid forcing a heavyweight runtime or replacing Acode's native file icons during the first native build. The remaining small P.T.P `assets/` support files are bundled. The full upstream P.T.P archive remains the source of record for later migration of runtime, icons, terminal, debugger, formatter and theme services.

## Important integration boundary

This is a **native bundled-engine integration candidate**, not yet a completed single CodeMirror completion-source rewrite. The Python, Dart and HTML/CSS engines still use their proven upstream CodeMirror compartments/adapters. Because each engine is language/path scoped, only its matching language provider returns suggestions for the active document. A later phase can refactor their private providers behind one Acode-owned completion arbiter after device-level regression testing.

No claim is made that a final APK has been built or tested on an Android device. The source needs the normal Acode toolchain and a successful compile before it can be considered build-verified.

## Build

Use the repository's normal build workflow (the same as unmodified Acode 1.13.5):

1. Install the Node.js dependencies declared by `package.json` (`npm ci`).
2. Ensure the Cordova Android toolchain, Android SDK, Java/Gradle requirements and Android platform dependencies are installed as required by Acode 1.13.5.
3. Run `npm run build -- paid dev apk` for a development APK, or `npm run build -- paid prod apk` for a production APK.

The build script may need the project-specific Cordova plugins and Android SDK configuration on the machine doing the compilation. This archive contains the source changes, not a prebuilt APK.

## Source layout

- `src/cm/languageEngines/registry.ts` — host registry.
- `src/cm/nativeLanguageEngines.js` — bundled engine bootstrap.
- `src/main.js` — startup hook after external plugins are loaded.
- `www/native-language-engines/python/` — bundled P.T.P source and small support assets.
- `www/native-language-engines/dart/main.js` — bundled D.T.P source.
- `www/native-language-engines/web/main.js` — bundled H.S.T.P source.
- `tests/native-language-engines/` — upstream engine and lifecycle regression tests retained for follow-up validation.

## First Android acceptance tests

After compiling and installing the APK:

1. Open a `.py` file and verify Python suggestions for `import`, `class`, local variables, function arguments and member access.
2. Open a `.dart` file and verify Dart type/member suggestions (for example `String`, `List`, class members and extension members).
3. Open `.html` and `.css` files and verify HTML tag/attribute completion and CSS property/value completion.
4. Switch between all three file types repeatedly and confirm no suggestions from the wrong language appear.
5. Close and reopen files, then rotate/reopen the editor if supported; verify the engines remain active and no duplicate suggestion entries accumulate.

Do not mark this candidate stable until the Android tests pass on the target Acode build.
