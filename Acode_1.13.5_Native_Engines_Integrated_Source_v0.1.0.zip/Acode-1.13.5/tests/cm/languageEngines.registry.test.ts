import { describe, expect, it, vi } from "vitest";
import { LanguageEngineRegistry } from "../../src/cm/languageEngines/registry";

describe("LanguageEngineRegistry", () => {
  it("routes by language and file extension", () => {
    const registry = new LanguageEngineRegistry();
    registry.register({ id: "python", languages: ["Python"], extensions: ["py"] });
    registry.register({ id: "web", languages: ["html", "css"], extensions: ["html", ".css"] });
    expect(registry.resolve("/project/main.py")?.id).toBe("python");
    expect(registry.resolve("/project/index.HTML", "html")?.id).toBe("web");
    expect(registry.resolve("/project/site.css")?.id).toBe("web");
    expect(registry.resolve("/project/readme.md")).toBeNull();
  });

  it("rejects duplicate identifiers and supports unregister", () => {
    const registry = new LanguageEngineRegistry();
    registry.register({ id: "dart", languages: ["dart"], extensions: ["dart"] });
    expect(() => registry.register({ id: "DART", languages: ["dart"], extensions: ["dart"] })).toThrow(/already registered/u);
    expect(registry.unregister("dart")).toBe(true);
    expect(registry.unregister("dart")).toBe(false);
  });

  it("activates once and deactivates on unregister", async () => {
    const registry = new LanguageEngineRegistry();
    const activate = vi.fn();
    const deactivate = vi.fn();
    registry.register({ id: "python", languages: ["python"], extensions: ["py"], activate, deactivate });
    await registry.activate("python");
    await registry.activate("python");
    expect(activate).toHaveBeenCalledTimes(1);
    expect(registry.list()[0].active).toBe(true);
    registry.unregister("python");
    expect(deactivate).toHaveBeenCalledTimes(1);
  });

  it("returns only active completion sources in priority order", async () => {
    const registry = new LanguageEngineRegistry();
    const low = vi.fn(() => "low");
    const high = vi.fn(() => "high");
    registry.register({ id: "low", languages: ["python"], extensions: ["py"], priority: 1, complete: low });
    registry.register({ id: "high", languages: ["dart"], extensions: ["dart"], priority: 10, complete: high });
    await registry.activate("low");
    expect(registry.getCompletionSources()).toEqual([low]);
    await registry.activate("high");
    expect(registry.getCompletionSources()).toEqual([high, low]);
  });

  it("disposes engines in reverse registration order", async () => {
    const registry = new LanguageEngineRegistry();
    const order: string[] = [];
    registry.register({ id: "one", languages: ["one"], extensions: ["one"], deactivate: () => { order.push("one"); } });
    registry.register({ id: "two", languages: ["two"], extensions: ["two"], deactivate: () => { order.push("two"); } });
    await registry.activate("one");
    await registry.activate("two");
    await registry.dispose();
    expect(order).toEqual(["two", "one"]);
    expect(registry.list()).toEqual([]);
  });
});

describe("LanguageEngineRegistry dispatch", () => {
  it("dispatches completion only to the active engine resolved for the document", async () => {
    const registry = new LanguageEngineRegistry();
    const python = vi.fn(() => ({ options: [{ label: "python-result" }] }));
    const dart = vi.fn(() => ({ options: [{ label: "dart-result" }] }));
    registry.register({ id: "python", languages: ["python"], extensions: ["py"], complete: python });
    registry.register({ id: "dart", languages: ["dart"], extensions: ["dart"], complete: dart });
    expect(registry.complete({ path: "/src/main.py", language: "python", view: null })).toBeNull();
    await registry.activate("python");
    expect(registry.complete({ path: "/src/main.py", language: "python", view: null })).toEqual({ options: [{ label: "python-result" }] });
    expect(python).toHaveBeenCalledTimes(1);
    expect(dart).not.toHaveBeenCalled();
  });

  it("prefers an explicit language match over a colliding extension", () => {
    const registry = new LanguageEngineRegistry();
    registry.register({ id: "language-owner", languages: ["special"], extensions: ["shared"] });
    registry.register({ id: "extension-owner", languages: ["other"], extensions: ["shared"], priority: 99 });
    expect(registry.resolve("file.shared", "special")?.id).toBe("language-owner");
  });
});
