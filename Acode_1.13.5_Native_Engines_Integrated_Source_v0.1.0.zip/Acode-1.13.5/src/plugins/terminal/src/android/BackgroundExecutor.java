package com.foxdebug.acode.rk.exec.terminal;

import org.apache.cordova.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import com.foxdebug.acode.rk.exec.terminal.*;

public class BackgroundExecutor extends CordovaPlugin {

    private final Map<String, Process> processes = new ConcurrentHashMap<>();
    private final Map<String, OutputStream> processInputs = new ConcurrentHashMap<>();
    private final Map<String, CallbackContext> processCallbacks = new ConcurrentHashMap<>();
    private final Map<String, ProcessDetails> processDetails = new ConcurrentHashMap<>();
    private ProcessManager processManager;

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.processManager = new ProcessManager(cordova.getContext());
    }

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        switch (action) {
            case "start":
                String pid = UUID.randomUUID().toString();
                startProcess(pid, args.getString(0), args.getString(1).equals("true"), callbackContext);
                return true;
            case "write":
                writeToProcess(args.getString(0), args.getString(1), callbackContext);
                return true;
            case "stop":
                stopProcess(args.getString(0), callbackContext);
                return true;
            case "exec":
                exec(args.getString(0), args.getString(1).equals("true"), callbackContext);
                return true;
            case "isRunning":
                isProcessRunning(args.getString(0), callbackContext);
                return true;
            case "listProcesses":
                listProcesses(callbackContext);
                return true;
            case "listAllProcesses":
                listAllProcesses(callbackContext);
                return true;
            case "killProcess":
                killProcess(args.getInt(0), callbackContext);
                return true;
            case "loadLibrary":
                loadLibrary(args.getString(0), callbackContext);
                return true;
            case "setProotDebug":
                ProcessManager.prootDebug = args.getBoolean(0);
                callbackContext.success("PRoot debug " + (ProcessManager.prootDebug ? "enabled" : "disabled"));
                return true;
            default:
                callbackContext.error("Unknown action: " + action);
                return false;
        }
    }

    private void exec(String cmd, boolean useAlpine, CallbackContext callbackContext) {
        cordova.getThreadPool().execute(() -> {
            try {
                ProcessManager.ExecResult result = processManager.executeCommand(cmd, useAlpine);
                
                if (result.isSuccess()) {
                    callbackContext.success(result.stdout);
                } else {
                    callbackContext.error(result.getErrorMessage());
                }
            } catch (Exception e) {
                callbackContext.error("Exception: " + e.getMessage());
            }
        });
    }

    private void startProcess(String pid, String cmd, boolean useAlpine, CallbackContext callbackContext) {
        cordova.getThreadPool().execute(() -> {
            try {
                ProcessBuilder builder = processManager.createProcessBuilder(cmd, useAlpine);
                Process process = builder.start();

                long pidVal = ProcessUtils.getPid(process);
                processes.put(pid, process);
                processInputs.put(pid, process.getOutputStream());
                processCallbacks.put(pid, callbackContext);
                processDetails.put(pid, new ProcessDetails(cmd, useAlpine, pidVal));

                sendPluginResult(callbackContext, pid, true);

                // Stream stdout
                new Thread(() -> StreamHandler.streamOutput(
                    process.getInputStream(), 
                    line -> sendPluginMessage(pid, "stdout:" + line)
                )).start();
                
                // Stream stderr
                new Thread(() -> StreamHandler.streamOutput(
                    process.getErrorStream(), 
                    line -> sendPluginMessage(pid, "stderr:" + line)
                )).start();

                int exitCode = process.waitFor();
                sendPluginMessage(pid, "exit:" + exitCode);
                cleanup(pid);
            } catch (Exception e) {
                callbackContext.error("Failed to start process: " + e.getMessage());
            }
        });
    }

    private void writeToProcess(String pid, String input, CallbackContext callbackContext) {
        try {
            OutputStream os = processInputs.get(pid);
            if (os != null) {
                StreamHandler.writeToStream(os, input);
                callbackContext.success("Written to process");
            } else {
                callbackContext.error("Process not found or closed");
            }
        } catch (IOException e) {
            callbackContext.error("Write error: " + e.getMessage());
        }
    }

    private void stopProcess(String pid, CallbackContext callbackContext) {
        Process process = processes.get(pid);
        if (process != null) {
            ProcessUtils.killProcessTree(process);
            cleanup(pid);
            callbackContext.success("Process terminated");
        } else {
            callbackContext.error("No such process");
        }
    }

    private void isProcessRunning(String pid, CallbackContext callbackContext) {
        Process process = processes.get(pid);
        
        if (process != null) {
            String status = ProcessUtils.isAlive(process) ? "running" : "exited";
            if (status.equals("exited")) cleanup(pid);
            callbackContext.success(status);
        } else {
            callbackContext.success("not_found");
        }
    }

    private void listProcesses(CallbackContext callbackContext) {
        JSONArray result = new JSONArray();

        for (Map.Entry<String, Process> entry : processes.entrySet()) {
            String id = entry.getKey();
            Process process = entry.getValue();
            if (!ProcessUtils.isAlive(process)) continue;

            ProcessDetails details = processDetails.get(id);
            if (details == null) continue;

            try {
                JSONObject item = new JSONObject();
                item.put("id", id);
                item.put("command", details.command);
                item.put("alpine", details.alpine);
                item.put("startedAt", details.startedAt);
                item.put("pid", details.pid);
                result.put(item);
            } catch (JSONException ignored) {
                // These values are generated internally and should always serialize.
            }
        }

        callbackContext.success(result);
    }

    private void loadLibrary(String path, CallbackContext callbackContext) {
        callbackContext.error("This feature is no longer supported. Loading native libraries directly from JavaScript is no longer allowed due to security reasons.");
        /*try {
            System.load(path);
            callbackContext.success("Library loaded successfully.");
        } catch (Exception e) {
            callbackContext.error("Failed to load library: " + e.getMessage());
        }*/
    }

    private void sendPluginResult(CallbackContext ctx, String message, boolean keepCallback) {
        PluginResult result = new PluginResult(PluginResult.Status.OK, message);
        result.setKeepCallback(keepCallback);
        ctx.sendPluginResult(result);
    }

    private void sendPluginMessage(String pid, String message) {
        CallbackContext ctx = processCallbacks.get(pid);
        if (ctx != null) {
            sendPluginResult(ctx, message, true);
        }
    }

    private void cleanup(String pid) {
        processes.remove(pid);
        processInputs.remove(pid);
        processCallbacks.remove(pid);
        processDetails.remove(pid);
    }

    private void listAllProcesses(CallbackContext callbackContext) {
        try {
            callbackContext.success(ProcessUtils.getAllProcesses());
        } catch (Exception e) {
            callbackContext.error("Failed to list all processes: " + e.getMessage());
        }
    }

    private void killProcess(int pid, CallbackContext callbackContext) {
        try {
            ProcessUtils.killProcess(pid);
            callbackContext.success("Process terminated");
        } catch (Exception e) {
            callbackContext.error("Failed to kill process: " + e.getMessage());
        }
    }

    private static class ProcessDetails {
        final String command;
        final boolean alpine;
        final long startedAt;
        final long pid;

        ProcessDetails(String command, boolean alpine, long pid) {
            this.command = command;
            this.alpine = alpine;
            this.startedAt = System.currentTimeMillis();
            this.pid = pid;
        }
    }
}
