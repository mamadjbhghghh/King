# D.T.P Build 1.00.13 — Change Audit

## Scope
**Shared Semantic Graph, Open-Document Dependency Tracking & Targeted Document Reuse**

This build creates a shared per-document semantic record used by completion and diagnostics. The graph only includes Dart documents already exposed by Acode; it does not scan closed files or crawl project storage.

## Implemented
- Added a bounded semantic graph for up to 64 currently open Dart documents. Each record contains the source snapshot, fingerprint, parsed compilation-unit AST, analyzed symbol tables, document revision, and a symbol definition/reference index.
- Added directed dependency edges for resolvable relative imports, package imports, exports and `part` directives. Conditional imports are intentionally not guessed.
- Added reverse-dependency lookup and cycle-safe affected-document closure. When a document is edited, added or removed, the graph reports its transitive open-document dependents using both the previous and current dependency relations.
- Added package-configuration change detection. A changed package mapping marks documents with affected `package:` imports without reparsing unchanged source text.
- Added content-identity reuse: unchanged documents retain the same AST, symbol table and revision; only newly added or text-changed documents are reparsed and re-analyzed. Dependency edges are refreshed against the current open-document set.
- Integrated the graph into the live completion and diagnostics paths. The active AST and project symbol cache are sourced from the shared graph records; removed/closed documents are pruned from the semantic symbol cache.
- Added a hard document cap before parsing so a workspace larger than the cap does not repeatedly evict and reparse the same files.
- Fixed an existing typedef inference gap discovered by replaying the older engine suite: local variables typed through simple, generic, imported and re-exported typedef aliases now resolve to their underlying type before member completion.

## Explicit boundaries
- This is document-level incremental reuse and dependency-aware invalidation, not edit-range incremental parsing. A changed document is still parsed as a whole.
- The graph computes affected dependents, but the existing project namespace merge is still rebuilt from the open-document set for a completion request. This build does not claim a fully incremental compiler-style semantic scheduler.
- Symbol references are a lightweight same-document index derived from lexer identifiers and known declarations; this is not a complete Dart reference search or rename engine.
- Only open Acode documents are indexed. Closed files, arbitrary workspace crawling and filesystem watching are not implemented.
- Conditional imports/exports, unresolved paths, package sources not currently open, and external dependencies are not synthesized.
- This is not the Dart Analyzer, compiler, LSP, complete grammar, or Flutter Analyzer.

## Test evidence
- Current inherited expression/front-end engine suite plus four typedef-alias regression cases: **94/94 PASS**.
- New semantic graph suite: **26/26 PASS**.
- Current mocked CodeMirror provider/lifecycle suite, including cross-file completion and dependency-edit refresh: **19/19 PASS**.
- Historical engine suites from Builds 1.00.01–1.00.12: **631/631 PASS**.
- Historical lifecycle mock suites that still use the current extension composition contract (Builds 1.00.01–1.00.05 and 1.00.09–1.00.12): **54/54 PASS**. The 1.00.06–1.00.08 lifecycle mocks target a retired extension object shape and are not treated as valid current integration tests; the current 1.00.13 lifecycle suite directly covers the combined extension path.
- JavaScript syntax and package integrity checks: PASS.

These are local automated and mocked tests. Real Acode-device acceptance remains pending.
