# Native Language Engines — Candidate 0.1.0 status

- [x] Complete Acode 1.13.5 source retained, including original `www/` files.
- [x] Shared `LanguageEngineRegistry` included.
- [x] Registry unit test included under `tests/cm/`.
- [x] P.T.P 3.00 RC source bundled under Acode `www/`.
- [x] D.T.P 1.00.13 source bundled under Acode `www/`.
- [x] H.S.T.P 1.00.04 source bundled under Acode `www/`.
- [x] Acode startup calls the native engine bootstrap after regular plugin loading.
- [x] Standalone plugin instances are unmounted before built-in copies are activated.
- [x] Pyodide runtime and Material Icons Advanced are explicitly detached from this first engine-focused candidate.
- [x] Upstream smoke/regression test files are retained under `tests/native-language-engines/`.
- [x] All three bundled JavaScript files and the native bootstrap pass `node --check`.
- [x] ZIP integrity and original Acode file preservation verified.
- [ ] Full dependency install / Rspack build (not run; dependencies are not installed in this environment).
- [ ] Cordova Android APK build (not run).
- [ ] Real-device Acode acceptance tests (not run).
- [ ] Single Acode-owned completion arbitration layer (future phase).

This is an integrated source candidate, not a build-verified APK or a final unified completion pipeline.
