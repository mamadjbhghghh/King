import fonts from "lib/fonts";
import settings from "lib/settings";
import { isDeviceDarkTheme } from "lib/systemConfiguration";
import { updateActiveTerminals } from "settings/terminalSettings";
import color from "utils/color";
import ThemeBuilder from "./builder";
import themes, { updateSystemTheme } from "./preInstalled";

/** @type {Map<string, ThemeBuilder>} */
const appThemes = new Map();
let themeApplied = false;
let firstTime = true;

const darkModeMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
let systemThemeWatcherActive = false;

function init() {
	themes.forEach((theme) => add(theme));
	updateSystemThemeWatcher(settings.value.appTheme);
	settings.on("update:appTheme", updateSystemThemeWatcher);
}

/**
 * @typedef {object} Theme
 * @property {string} id
 * @property {string} name
 * @property {string} type
 * @property {string} version
 * @property {string} primaryColor
 */

/**
 * Returns a list of all themes
 * @returns {Theme[]}
 */
function list() {
	return Array.from(appThemes.keys()).map((name) => {
		const { id, type, primaryColor, version } = appThemes.get(name);
		return {
			id,
			type,
			version,
			primaryColor,
			name: name.capitalize(),
		};
	});
}

/**
 *
 * @param {string} name
 * @returns {ThemeBuilder}
 */
function get(name) {
	return appThemes.get(name.toLowerCase());
}

/**
 *
 * @param {ThemeBuilder} theme
 * @returns
 */
function add(theme) {
	if (!(theme instanceof ThemeBuilder)) return;
	if (appThemes.has(theme.id)) return;

	appThemes.set(theme.id, theme);

	const { appTheme } = settings.value;

	if (theme.matches(appTheme)) {
		if (appTheme !== "system") {
			apply(appTheme);
		} else {
			updateSystemTheme(isDeviceDarkTheme());
			themeApplied = true;
		}
	}
}

/**
 * Apply a theme
 * @param {string} id The name of the theme to apply
 * @param {boolean} init Whether or not this is the first time the theme is being applied
 */
export async function apply(id, init) {
	if (!DOES_SUPPORT_THEME) {
		id = "default";
	}
	if (id.toLowerCase() === "system") {
		// Refresh the mutable System theme before reading its preferred editor
		// theme. Do not re-enter apply() while appTheme is being updated below.
		updateSystemTheme(isDeviceDarkTheme(), false);
	}

	themeApplied = true;
	const theme = get(id);
	const $style = document.head.get("style#app-theme") ?? (
		<style id="app-theme"></style>
	);
	const update = {
		appTheme: id,
	};

	if (id === "custom") {
		update.customTheme = theme.toJSON();
	}

	if (init && theme.preferredEditorTheme) {
		update.editorTheme = theme.preferredEditorTheme;
		if (editorManager != null && editorManager.editor != null) {
			editorManager.editor.setTheme(theme.preferredEditorTheme);
		}
	}

	if (init && theme.preferredFont) {
		update.editorFont = theme.preferredFont;
		fonts.setFont(theme.preferredFont);
	}

	if (init && firstTime && theme.preferredTerminalTheme) {
		update.terminalSettings = {
			...(settings.value.terminalSettings || {}),
			theme: theme.preferredTerminalTheme,
		};
	}

	settings.update(update, false);

	if (init && firstTime && theme.preferredTerminalTheme) {
		if (editorManager != null) {
			updateActiveTerminals("theme", theme.preferredTerminalTheme);
		}
	}

	localStorage.__primary_color = theme.primaryColor;
	document.body.setAttribute("theme-type", theme.type);
	$style.textContent = theme.css;
	document.head.append($style);

	const primaryColor = color(theme.primaryColor).hex.toString();
	const scheme = theme.toJSON("hex");
	// Set status bar and navigation bar color
	system.setUiTheme(primaryColor, scheme);

	if (firstTime) {
		// To make sure system bars are updated
		setTimeout(() => {
			system.setUiTheme(primaryColor, scheme);
		}, 1000);
		firstTime = false;
	}
}

/**
 * Update a theme
 * @param {ThemeBuilder} theme
 */
export function update(theme) {
	if (!(theme instanceof ThemeBuilder)) return;
	const oldTheme = get(theme.id);
	if (!oldTheme) {
		add(theme);
		return;
	}
	const json = theme.toJSON();
	Object.keys(json).forEach((key) => {
		oldTheme[key] = json[key];
	});
}

function syncSystemTheme(event, applyTheme = true) {
	if (settings.value.appTheme.toLowerCase() !== "system") return;
	const isDark = event ? event.matches : darkModeMediaQuery.matches;
	updateSystemTheme(isDark, applyTheme);
}

function startSystemThemeWatcher() {
	if (systemThemeWatcherActive) return;
	systemThemeWatcherActive = true;
	if (typeof darkModeMediaQuery.addEventListener === "function") {
		darkModeMediaQuery.addEventListener("change", syncSystemTheme);
	} else {
		darkModeMediaQuery.addListener(syncSystemTheme);
	}
}

function stopSystemThemeWatcher() {
	if (!systemThemeWatcherActive) return;
	systemThemeWatcherActive = false;
	if (typeof darkModeMediaQuery.removeEventListener === "function") {
		darkModeMediaQuery.removeEventListener("change", syncSystemTheme);
	} else {
		darkModeMediaQuery.removeListener(syncSystemTheme);
	}
}

/**
 * Start or stop syncing the app theme with the OS color scheme
 * @param {string} theme
 */
export function updateSystemThemeWatcher(theme) {
	if (String(theme).toLowerCase() === "system") {
		startSystemThemeWatcher();
		// Starting the watcher happens from the appTheme update listener. Applying
		// the theme here would update appTheme again before the first settings
		// update is saved, causing unbounded synchronous recursion.
		syncSystemTheme(undefined, false);
		return;
	}
	stopSystemThemeWatcher();
}

export default {
	get applied() {
		return themeApplied;
	},
	init,
	list,
	get,
	add,
	apply,
	update,
	updateSystemThemeWatcher,
};
