const fs = require('fs');
const vm = require('vm');
const path = require('path');
const root = __dirname;
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'python-runtime/runtime-main.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'plugin.json'), 'utf8'));
const modules = JSON.parse(fs.readFileSync(path.join(root, 'ptp-modules.json'), 'utf8'));
let pass = 0, fail = 0;
function check(name, condition, detail='') {
  if (condition) pass++; else fail++;
  console.log(`${condition ? 'PASS' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
}
check('manifest and internal build use the candidate version', manifest.version === '3.00' && main.includes('const TOOLKIT_VERSION = "3.00"'));
check('runtime module is attached in registry', main.includes('pyodideRuntime: Object.freeze({ id: "ptp.pyodide-runtime", state: "attached"'));
check('icon pack remains attached after full integration', main.includes('materialIconsAdvanced: Object.freeze({ id: "ptp.material-icons-advanced", state: "attached"'));
check('unified P.T.P lifecycle remains sole plugin registrar', bridge.includes('__ACODE_PTP_PYTHON_RUNTIME_FACTORY__') && !bridge.includes('setPluginInit(') && !bridge.includes('setPluginUnmount('));
check('runtime factory exposes the expected handle API', bridge.includes('runtime,') && bridge.includes('async init(baseUrl, page, options = {})') && bridge.includes('destroy()'));
check('runtime uses the local packaged worker', bridge.includes('new Worker(`${this.baseUrl}worker.js`,{type:"module"})'));
check('stable Acode event callback is used for register and unregister', bridge.includes('this.__ptpCheckRunnableHandler=this.checkRunnable.bind(this)') && bridge.includes('editorManager.off("switch-file",this.__ptpCheckRunnableHandler)'));
check('stdin cache bridge is required rather than silently faked', bridge.includes('options.cacheFile.writeFile') && bridge.includes('options.cacheFileUrl'));
check('Python engine, stdlib and lock assets are declared', manifest.files.includes('python-runtime/lib/pyodide.asm.wasm') && manifest.files.includes('python-runtime/lib/python_stdlib.zip') && manifest.files.includes('python-runtime/lib/pyodide-lock.json'));
check('Acode manifest readme target exists and is declared', fs.existsSync(path.join(root, 'readme.md')) && manifest.files.includes('readme.md'));
check('runtime module checksums are present', Object.keys((modules.attached_modules.find(item => item.id === 'ptp.pyodide-runtime') || {}).sha256 || {}).length === 8);
check('upstream attribution remains present', fs.readFileSync(path.join(root, 'THIRD_PARTY_NOTICES.md'), 'utf8').includes('Acode-Foundation/acode-plugin-python'));
console.log(`SUMMARY ${pass}/${pass+fail} PASS; ${fail} FAIL`);
if (fail) process.exitCode = 1;
