const assert = require('node:assert/strict');

const localStorageData = new Map();
global.window = {
  localStorage: { getItem(key) { return localStorageData.has(key) ? localStorageData.get(key) : null; }, setItem(key, value) { localStorageData.set(key, String(value)); } },
  __ACODE_HSTP_TESTING__: true,
  editorManager: { activeFile: { filename: '/workspace/index.html' } },
  acode: { require(name) { return name === '@codemirror/autocomplete' ? { pickedCompletion: { of: completion => ({ type: 'pickedCompletion', completion }) } } : null; }, setPluginInit() {}, setPluginUnmount() {} }
};
require('../main.js');
const api = global.window.__acodeHSTPTest;
if (!api) throw new Error('H.S.T.P test bridge was not exposed.');

let passed = 0;
const results = [];
function check(name, fn) {
  try { fn(); passed++; results.push(`PASS ${name}`); }
  catch (error) { results.push(`FAIL ${name}: ${error.message}`); }
}
function labels(result) { return new Set((result?.options || []).map(option => option.label)); }
function has(result, label) { assert.ok(labels(result).has(label), `expected suggestion: ${label}`); }
function findOption(result, label) {
  const option = result?.options?.find(item => item.label === label);
  assert.ok(option, `expected suggestion: ${label}`);
  return option;
}
function applyOption(filePath, text, pos, label) {
  const result = api.resolveCompletions(filePath, text, pos);
  const option = findOption(result, label);
  let currentText = text;
  let cursor = pos;
  let lastTransaction = null;
  const doc = {
    toString: () => currentText,
    sliceString: (from, to) => currentText.slice(from, to)
  };
  const view = {
    state: { doc },
    dispatch(transaction) {
      lastTransaction = transaction;
      if (transaction.changes) {
        const change = transaction.changes;
        currentText = currentText.slice(0, change.from) + change.insert + currentText.slice(change.to);
      }
      if (transaction.selection?.anchor != null) cursor = transaction.selection.anchor;
    }
  };
  assert.equal(typeof option.apply, 'function', `${label} should have a context-aware apply handler`);
  option.apply(view, option, result.from, pos);
  return { text: currentText, cursor, transaction: lastTransaction };
}

// Preserve the Build 1.00.01 completion coverage.
check('HTML file extension is detected', () => assert.equal(api.languageForPath('/site/index.HTML'), 'html'));
check('CSS file extension is detected', () => assert.equal(api.languageForPath('/site/styles.css'), 'css'));
check('JavaScript file is outside HSTP scope', () => assert.equal(api.languageForPath('/site/app.js'), ''));
check('HTML tag completion offers div for <di', () => has(api.resolveCompletions('/site/index.html', '<di', 3), 'div'));
check('HTML tag completion offers semantic header', () => has(api.resolveCompletions('/site/index.html', '<hea', 4), 'header'));
check('HTML closing-tag completion recognizes </di', () => has(api.resolveCompletions('/site/index.html', '</di', 4), 'div'));
check('HTML attribute completion offers placeholder on input', () => has(api.resolveCompletions('/site/index.html', '<input pla', 10), 'placeholder'));
check('HTML tag-specific input completion offers type', () => has(api.resolveCompletions('/site/index.html', '<input ty', 9), 'type'));
check('HTML global attributes include class', () => has(api.resolveCompletions('/site/index.html', '<section cla', 12), 'class'));
check('HTML attribute value completion offers email', () => has(api.resolveCompletions('/site/index.html', '<input type="em', 15), 'email'));
check('HTML attribute value completion offers target blank', () => has(api.resolveCompletions('/site/index.html', '<a target="_b', 13), '_blank'));
check('HTML attribute value completion offers rel stylesheet', () => has(api.resolveCompletions('/site/index.html', '<link rel="sty', 14), 'stylesheet'));
check('HTML comment content is not completed as markup', () => assert.equal(api.resolveCompletions('/site/index.html', '<!-- <di', 8), null));
check('HTML text content is not mistaken for an open tag', () => assert.equal(api.resolveCompletions('/site/index.html', 'Welcome to the page', 19), null));
check('CSS property completion offers display', () => has(api.resolveCompletions('/site/styles.css', '.card { dis', 11), 'display'));
check('CSS property completion offers border-radius', () => has(api.resolveCompletions('/site/styles.css', '.card { border-r', 15), 'border-radius'));
check('CSS display values offer flex', () => has(api.resolveCompletions('/site/styles.css', '.card { display: fle', 20), 'flex'));
check('CSS display values offer grid', () => has(api.resolveCompletions('/site/styles.css', '.card { display: gr', 19), 'grid'));
check('CSS position values offer absolute', () => has(api.resolveCompletions('/site/styles.css', '.card { position: ab', 21), 'absolute'));
check('CSS color values offer red', () => has(api.resolveCompletions('/site/styles.css', '.card { color: re', 18), 'red'));
check('CSS at-rule completion offers @media', () => has(api.resolveCompletions('/site/styles.css', '@med', 4), '@media'));
check('CSS pseudo-class completion offers hover', () => has(api.resolveCompletions('/site/styles.css', 'a:hov', 5), 'hover'));
check('CSS pseudo-element completion offers before', () => has(api.resolveCompletions('/site/styles.css', 'p::be', 5), 'before'));
check('CSS does not suggest declarations outside a rule', () => assert.equal(api.resolveCompletions('/site/styles.css', 'display: fle', 12), null));
check('CSS comment content is ignored', () => assert.equal(api.resolveCompletions('/site/styles.css', '/* .card { dis', 14), null));
check('CSS property context is distinguished from value context', () => {
  const result = api.resolveCompletions('/site/styles.css', '.card { display: fle', 20);
  has(result, 'flex'); assert.ok(!labels(result).has('flex-direction'));
});
check('Completion metadata contains descriptions and semantic kinds', () => {
  const option = api.resolveCompletions('/site/styles.css', '.card { dis', 11).options.find(item => item.label === 'display');
  assert.equal(option.type, 'property'); assert.ok(option.detail.length > 0);
});
check('HTML and CSS language contexts remain isolated', () => {
  assert.equal(api.resolveCompletions('/site/app.js', '<di', 3), null);
  assert.equal(api.resolveCompletions('/site/index.html', '.card { dis', 11), null);
});

// New Build 1.00.02 behavior: real apply handlers and syntax scaffolding.
check('Selecting div inserts an opening and matching closing tag with cursor inside', () => {
  const result = applyOption('/site/index.html', '<di', 3, 'div');
  assert.equal(result.text, '<div></div>');
  assert.equal(result.cursor, 5);
});
check('Selecting style inserts </style> and places cursor in the style body', () => {
  const result = applyOption('/site/index.html', '<sty', 4, 'style');
  assert.equal(result.text, '<style></style>');
  assert.equal(result.cursor, 7);
});
check('Selecting script inserts </script> and places cursor in the script body', () => {
  const result = applyOption('/site/index.html', '<scr', 4, 'script');
  assert.equal(result.text, '<script></script>');
  assert.equal(result.cursor, 8);
});
check('Void HTML tags are closed with > but do not receive an ending tag', () => {
  const result = applyOption('/site/index.html', '<inp', 4, 'input');
  assert.equal(result.text, '<input>');
  assert.equal(result.cursor, 7);
});
check('Closing-tag completion does not generate a second closing tag', () => {
  const result = applyOption('/site/index.html', '</di', 4, 'div');
  assert.equal(result.text, '</div>');
  assert.equal(result.cursor, 6);
});
check('Selecting a normal HTML attribute creates empty quotes and places cursor inside', () => {
  const result = applyOption('/site/index.html', '<input pla', 10, 'placeholder');
  assert.equal(result.text, '<input placeholder=""');
  assert.equal(result.cursor, 20);
});
check('Selecting a boolean HTML attribute does not create a value pair', () => {
  const result = applyOption('/site/index.html', '<input dis', 10, 'disabled');
  assert.equal(result.text, '<input disabled ');
  assert.equal(result.cursor, 16);
});
check('Selecting a boolean attribute does not duplicate an existing space', () => {
  const result = applyOption('/site/index.html', '<input dis ', 10, 'disabled');
  assert.equal(result.text, '<input disabled ');
  assert.equal(result.cursor, 15);
});
check('Selecting an HTML attribute value adds its closing quote', () => {
  const result = applyOption('/site/index.html', '<input type="em', 15, 'email');
  assert.equal(result.text, '<input type="email"');
  assert.equal(result.cursor, 19);
});
check('CSS property completion inserts colon, space and semicolon with cursor after colon', () => {
  const result = applyOption('/site/styles.css', '.card { col', 11, 'color');
  assert.equal(result.text, '.card { color: ;');
  assert.equal(result.cursor, 15);
});
check('CSS value completion appends semicolon', () => {
  const result = applyOption('/site/styles.css', '.card { color: bl', 17, 'blue');
  assert.equal(result.text, '.card { color: blue;');
  assert.equal(result.cursor, 20);
});
check('CSS value completion preserves the semicolon scaffold inserted with the property', () => {
  const result = applyOption('/site/styles.css', '.card { color: bl;', 17, 'blue');
  assert.equal(result.text, '.card { color: blue;');
  assert.equal(result.cursor, 19);
});
check('CSS media at-rule inserts parentheses and a braced block', () => {
  const result = applyOption('/site/styles.css', '@med', 4, '@media');
  assert.equal(result.text, '@media () {\n  \n}');
  assert.equal(result.cursor, 8);
});
check('CSS function completion inserts balanced parentheses and comma slots', () => {
  const result = applyOption('/site/styles.css', '.card { color: rg', 17, 'rgb');
  assert.equal(result.text, '.card { color: rgb(, , );');
  assert.equal(result.cursor, 19);
});
check('CSS function completion preserves an existing declaration semicolon', () => {
  const result = applyOption('/site/styles.css', '.card { color: rg;', 17, 'rgb');
  assert.equal(result.text, '.card { color: rgb(, , );');
  assert.equal(result.cursor, 19);
});
check('Embedded CSS inside a style tag receives CSS property suggestions', () => {
  const source = '<style>\nh1 { col';
  const result = api.resolveCompletions('/site/index.html', source, source.length);
  has(result, 'color');
  assert.equal(result.embedded, true);
});
check('Embedded CSS property completion inserts declaration punctuation', () => {
  const source = '<style>\nh1 { col';
  const result = applyOption('/site/index.html', source, source.length, 'color');
  assert.equal(result.text, '<style>\nh1 { color: ;');
});
check('Manual opening style tag can be recognized for automatic closing on >', () => {
  assert.equal(api.htmlTagToAutoClose('<style', 6), 'style');
});
check('Manual opening script tag can be recognized for automatic closing on >', () => {
  assert.equal(api.htmlTagToAutoClose('<script', 7), 'script');
});
check('Manual void tags are excluded from automatic closing', () => {
  assert.equal(api.htmlTagToAutoClose('<img', 4), '');
});
check('HTML comments are excluded from manual tag auto-close', () => {
  assert.equal(api.htmlTagToAutoClose('<!-- <style', 11), '');
});
check('Typing parentheses creates a matched pair and places cursor between', () => {
  const plan = api.autoPairPlan('(', '', '');
  assert.equal(plan.insert, '()'); assert.equal(plan.cursor, 1);
});
check('Typing square brackets creates a matched pair', () => {
  const plan = api.autoPairPlan('[', '', '');
  assert.equal(plan.insert, '[]'); assert.equal(plan.cursor, 1);
});
check('Typing a CSS opening brace creates an indented block and closing brace', () => {
  const plan = api.autoPairPlan('{', '', '  ');
  assert.equal(plan.insert, '{\n    \n  }'); assert.equal(plan.cursor, 6);
});
check('Typing a quote creates a matched quote pair', () => {
  const plan = api.autoPairPlan('"', '', '');
  assert.equal(plan.insert, '""'); assert.equal(plan.cursor, 1);
});
check('Typing a closing delimiter before an existing one skips over it', () => {
  assert.equal(api.autoPairPlan(')', ')', '').kind, 'skip');
});



// Build 1.00.03: full tag display labels, standalone tag shorthand and practical multi-line snippets.
check('HTML tag completion visually displays a full opening tag for <h', () => {
  const result = api.resolveCompletions('/site/index.html', '<h', 2);
  const option = findOption(result, 'h1');
  assert.equal(option.displayLabel, '<h1>');
});
check('HTML tag completion visually displays a full closing tag for </h', () => {
  const result = api.resolveCompletions('/site/index.html', '</h', 3);
  const option = findOption(result, 'h1');
  assert.equal(option.displayLabel, '</h1>');
});
check('Typing h1 alone on an HTML line offers the <h1> tag shorthand', () => {
  const result = api.resolveCompletions('/site/index.html', 'h1', 2);
  const option = findOption(result, 'h1');
  assert.equal(result.kind, 'html-tag-shorthand');
  assert.equal(option.displayLabel, '<h1>');
});
check('Selecting standalone h1 expands to paired tags with cursor inside', () => {
  const result = applyOption('/site/index.html', 'h1', 2, 'h1');
  assert.equal(result.text, '<h1></h1>');
  assert.equal(result.cursor, 4);
});
check('Standalone shorthand supports all HTML tags, including div', () => {
  const result = applyOption('/site/index.html', 'div', 3, 'div');
  assert.equal(result.text, '<div></div>');
  assert.equal(result.cursor, 5);
});
check('Standalone shorthand does not create a closing tag for void img', () => {
  const result = applyOption('/site/index.html', 'img', 3, 'img');
  assert.equal(result.text, '<img>');
  assert.equal(result.cursor, 5);
});
check('HTML tag shorthand is limited to a standalone line and does not hijack prose', () => {
  assert.equal(api.resolveCompletions('/site/index.html', 'heading h1', 10), null);
});
check('HTML snippet trigger offers the full HTML5 document template', () => {
  const result = api.resolveCompletions('/site/index.html', '!ht', 3);
  has(result, '!html');
  assert.match(findOption(result, '!html').detail, /multi-line HTML template/);
});
check('Selecting !html inserts a complete indented document and positions cursor in title', () => {
  const result = applyOption('/site/index.html', '!html', 5, '!html');
  assert.match(result.text, /<!doctype html>[\s\S]*<meta name="viewport"[\s\S]*<title><\/title>[\s\S]*<main>[\s\S]*<script src="script.js" defer><\/script>/);
  assert.equal(result.cursor, result.text.indexOf('</title>'));
});
check('HTML contact-form snippet includes labels, required fields and submit button', () => {
  const result = applyOption('/site/index.html', '!form', 5, '!form');
  assert.match(result.text, /<label for="email">Email<\/label>/);
  assert.match(result.text, /type="email"[^>]*required/);
  assert.match(result.text, /<button type="submit">Send message<\/button>/);
});
check('HTML navigation snippet includes an accessible navigation landmark', () => {
  const result = applyOption('/site/index.html', '!nav', 4, '!nav');
  assert.match(result.text, /<nav aria-label="Main navigation">/);
  assert.match(result.text, /<ul>[\s\S]*<li>/);
});
check('HTML snippet preserves current line indentation on every inserted line', () => {
  const source = '  !nav';
  const result = applyOption('/site/index.html', source, source.length, '!nav');
  assert.match(result.text, /^  <nav/);
  assert.ok(result.text.includes('\n    <ul>'));
});
check('CSS property context offers multi-line Flexbox helper', () => {
  const source = '.layout {\n  flex-';
  const result = api.resolveCompletions('/site/styles.css', source, source.length);
  const option = findOption(result, 'flex-center');
  assert.match(option.detail, /multi-line CSS template/);
});
check('Selecting flex-center expands to a real multi-line Flexbox declaration group', () => {
  const source = '.layout {\n  flex-';
  const result = applyOption('/site/styles.css', source, source.length, 'flex-center');
  assert.equal(result.text, '.layout {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 1rem;');
  assert.equal(result.cursor, source.indexOf('flex-') + 'display: '.length);
});
check('Selecting grid-auto inserts responsive auto-fit grid declarations', () => {
  const source = '.grid {\n  grid-a';
  const result = applyOption('/site/styles.css', source, source.length, 'grid-auto');
  assert.match(result.text, /grid-template-columns: repeat\(auto-fit, minmax\(min\(100%, 16rem\), 1fr\)\);/);
  assert.match(result.text, /gap: 1rem;/);
});
check('Selecting visually-hidden inserts an accessibility utility block', () => {
  const source = '.sr-only {\n  visually';
  const result = applyOption('/site/styles.css', source, source.length, 'visually-hidden');
  assert.match(result.text, /position: absolute;/);
  assert.match(result.text, /clip: rect\(0, 0, 0, 0\);/);
  assert.match(result.text, /white-space: nowrap;/);
});
check('CSS snippets retain the existing rule indentation', () => {
  const source = '.card {\n    card-s';
  const result = applyOption('/site/styles.css', source, source.length, 'card-style');
  assert.match(result.text, /\n    border: 1px solid/);
  assert.match(result.text, /\n    box-shadow:/);
});
check('Embedded style blocks offer the same multi-line CSS helpers', () => {
  const source = '<style>\n.card {\n  flex-';
  const result = api.resolveCompletions('/site/index.html', source, source.length);
  has(result, 'flex-center');
  assert.equal(result.embedded, true);
});
check('Build version is synchronized in the engine', () => assert.equal(api.TOOLKIT_VERSION, '1.00.04'));

check('HTML and CSS snippets use the same standard completion row type', () => {
  const html = findOption(api.resolveCompletions('/site/index.html', '!ht', 3), '!html');
  const css = findOption(api.resolveCompletions('/site/styles.css', '.layout {\n  flex-', 18), 'flex-center');
  assert.equal(html.type, 'keyword');
  assert.equal(css.type, 'keyword');
  assert.equal(html.displayLabel, undefined);
  assert.equal(html.template, undefined);
  assert.equal(typeof html.apply, 'function');
});
check('All returned suggestions use a uniform CodeMirror apply callback', () => {
  const results = [
    api.resolveCompletions('/site/index.html', '<di', 3),
    api.resolveCompletions('/site/index.html', '<input pla', 10),
    api.resolveCompletions('/site/index.html', '!ht', 3),
    api.resolveCompletions('/site/styles.css', '.card { dis', 11),
    api.resolveCompletions('/site/styles.css', '.card { display: fle', 20)
  ];
  for (const result of results) for (const option of result.options) assert.equal(typeof option.apply, 'function');
});
check('Most recently accepted matching suggestion is ranked first', () => {
  api.recordRecentCompletion('h3', 'type');
  api.recordRecentCompletion('h2', 'type');
  const result = api.resolveCompletions('/site/index.html', '<h', 2);
  assert.equal(result.options[0].label, 'h2');
  assert.ok(result.options.findIndex(item => item.label === 'h2') < result.options.findIndex(item => item.label === 'h3'));
});
check('Recent-use history is persisted using the shared Toolkit Pro storage schema', () => {
  const stored = JSON.parse(localStorageData.get('com.jarvis.toolkit-pro.recent-completions.v1'));
  assert.equal(stored.version, 1);
  assert.ok(stored.entries.some(entry => entry.key === 'com.jarvis.html-css-toolkit-pro|type|h2'));
});
check('Selecting an HTML snippet records its recent use', () => {
  applyOption('/site/index.html', '!html', 5, '!html');
  assert.ok(api.readRecentCompletions().some(entry => entry.key === 'com.jarvis.html-css-toolkit-pro|keyword|!html'));
});
check('Custom snippet apply dispatches the CodeMirror pickedCompletion annotation', () => {
  const result = applyOption('/site/index.html', '!html', 5, '!html');
  assert.equal(result.transaction.annotations.type, 'pickedCompletion');
});
check('Snippet selection replaces the complete trigger rather than leaving trigger fragments', () => {
  const result = applyOption('/site/index.html', '!html', 5, '!html');
  assert.ok(result.text.startsWith('<!doctype html>'));
  assert.ok(!result.text.includes('!html'));
  assert.equal((result.text.match(/<!doctype html>/giu) || []).length, 1);
  assert.equal(result.transaction.annotations.type, 'pickedCompletion');
  assert.equal(result.transaction.annotations.completion.label, '!html');
});


check('Remaining HTML card, hero and table templates expand into semantic structures', () => {
  const card = applyOption('/site/index.html', '!card', 5, '!card').text;
  const hero = applyOption('/site/index.html', '!hero', 5, '!hero').text;
  const table = applyOption('/site/index.html', '!table', 6, '!table').text;
  assert.match(card, /<article class="card">[\s\S]*<img[^>]+alt="Descriptive image"[\s\S]*<h2/);
  assert.match(hero, /<section class="hero"[\s\S]*<h1 id="hero-title">A clear headline<\/h1>[\s\S]*hero__action/);
  assert.match(table, /<caption>Summary of records<\/caption>[\s\S]*<th scope="col">[\s\S]*<th scope="row">/);
});
check('Remaining CSS button, container and text-truncation templates expand correctly', () => {
  const button = applyOption('/site/styles.css', '.button {\n  button-s', 19, 'button-style').text;
  const containerSource = '.container {\n  responsive-';
  const container = applyOption('/site/styles.css', containerSource, containerSource.length, 'responsive-container').text;
  const truncateSource = '.title {\n  text-t';
  const truncate = applyOption('/site/styles.css', truncateSource, truncateSource.length, 'text-truncate').text;
  assert.match(button, /display: inline-flex;[\s\S]*cursor: pointer;[\s\S]*transition:/);
  assert.match(container, /width: min\(100% - 2rem, 72rem\);[\s\S]*margin-inline: auto;/);
  assert.match(truncate, /overflow: hidden;[\s\S]*text-overflow: ellipsis;[\s\S]*white-space: nowrap;/);
});

console.log(results.join('\n'));
console.log(`SUMMARY ${passed}/${results.length} PASS`);
if (passed !== results.length) process.exitCode = 1;
