const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const code = fs.readFileSync(__dirname + '/../main.js', 'utf8');
const sandbox = { window: { __ACODE_DTP_TESTING__: true }, console, setTimeout, clearTimeout, setInterval, clearInterval, Date, URL };
vm.runInNewContext(code, sandbox);
const api = sandbox.window.__acodeDTPTest;
let passed = 0, failed = 0;
function test(name, fn) { try { fn(); passed++; console.log('PASS ' + name); } catch (error) { failed++; console.error('FAIL ' + name + ': ' + error.stack); } }
const mainPath = '/workspace/app/lib/main.dart';
const modelPath = '/workspace/app/lib/models/user.dart';
const barrelPath = '/workspace/app/lib/api.dart';
const hiddenPath = '/workspace/app/lib/internal.dart';
const graph = api.createDartSemanticGraph(64);

const docs1 = new Map([
  [mainPath, "import 'models/user.dart';\nimport 'api.dart' show Api;\nvoid main() { final user = User(); user.greet(); Api(); }"],
  [modelPath, "class User { String greet() => 'hello'; }"],
  [barrelPath, "export 'internal.dart'; class Api {}"],
  [hiddenPath, "class Internal {}"]
]);
let first;
test('Build version is 1.00.13', () => assert.strictEqual(api.TOOLKIT_VERSION, '1.00.13'));
test('Graph API is exposed for deterministic engine tests', () => assert.strictEqual(typeof api.createDartSemanticGraph, 'function'));
test('Initial graph indexes four open Dart documents', () => { first = graph.update(docs1, mainPath); assert.strictEqual(graph.stats().documentCount, 4); assert.strictEqual(first.added.length, 4); });
test('Relative imports resolve to the normalized target document', () => { const deps = graph.getDependencies(mainPath); assert(deps.some(x => x.path === modelPath && x.kind === 'import')); });
test('Export directives are represented as dependency edges', () => assert(graph.getDependencies(barrelPath).some(x => x.path === hiddenPath && x.kind === 'export')));
test('Reverse dependency lookup identifies direct importer', () => assert(graph.getDependents(modelPath).includes(mainPath)));
test('Affected-document closure includes importer and imported declaration', () => { const affected = graph.getAffectedDocuments(modelPath); assert(affected.includes(modelPath)); assert(affected.includes(mainPath)); });
test('AST and symbol tables are stored in the shared document record', () => { const record = graph.getDocument(modelPath); assert.strictEqual(record.ast.kind, 'CompilationUnit'); assert(record.symbols.classes.has('User')); });
test('Symbol reference index records local variable usage', () => { const item = graph.getSymbol(mainPath, 'user'); assert(item && item.definitions.length >= 1 && item.references.length >= 1); });
test('Symbol reference index records method call through member syntax', () => { const item = graph.getSymbol(modelPath, 'greet'); assert(item && item.definitions.length >= 1); });
test('Unchanged update reuses all parsed ASTs', () => { const before = graph.stats().parsedDocuments; const result = graph.update(docs1, mainPath); assert.strictEqual(graph.stats().parsedDocuments, before); assert.strictEqual(result.unchanged.length, 4); assert.strictEqual(result.changed.length, 0); });
test('Unchanged records preserve AST object identity', () => { const before = graph.getDocument(modelPath).ast; graph.update(docs1, mainPath); assert.strictEqual(graph.getDocument(modelPath).ast, before); });
test('Editing dependency reparses only that document', () => { const edited = new Map(docs1); edited.set(modelPath, "class User { int id = 1; String greet() => 'hi'; }"); const before = graph.stats().parsedDocuments; const result = graph.update(edited, mainPath); assert.strictEqual(graph.stats().parsedDocuments, before + 1); assert.strictEqual(result.changed.join(','), modelPath); });
test('Dependency edit invalidates all open import dependents', () => { const affected = graph.lastUpdate().affected; assert(affected.includes(modelPath)); assert(affected.includes(mainPath)); });
test('Changed dependency advances only its own document revision', () => { const changed = graph.getDocument(modelPath); const stableMain = graph.getDocument(mainPath); assert(changed.revision > 0 && stableMain.revision > 0); assert.notStrictEqual(changed.ast, null); });
test('Newly added dependency document attaches to existing importers', () => { const docs = new Map(docs1); docs.set('/workspace/app/lib/new_api.dart', 'class NewApi {}'); docs.set(mainPath, docs.get(mainPath) + "\nimport 'new_api.dart';"); const result = graph.update(docs, mainPath); assert(result.added.includes('/workspace/app/lib/new_api.dart') || result.changed.includes(mainPath)); assert(graph.getDependents('/workspace/app/lib/new_api.dart').includes(mainPath)); });
test('Removed documents are purged from graph and reverse edges', () => { const docs = new Map(docs1); docs.delete(hiddenPath); graph.update(docs, mainPath); assert.strictEqual(graph.getDocument(hiddenPath), null); assert(!graph.getDependencies(barrelPath).some(x => x.path === hiddenPath)); });
test('Removed dependency invalidates former importer using previous reverse graph', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/r/root.dart', "export 'child.dart';"], ['/r/child.dart', 'class Child {}']]); g.update(docs, '/r/root.dart'); docs.delete('/r/child.dart'); const result = g.update(docs, '/r/root.dart'); assert(result.removed.includes('/r/child.dart')); assert(result.affected.includes('/r/root.dart')); });
test('Conditional imports are deliberately excluded from resolved dependency edges', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/x/main.dart', "import 'stub.dart' if (dart.library.io) 'io.dart';"], ['/x/stub.dart', 'class Stub {}'], ['/x/io.dart', 'class IO {}']]); g.update(docs, '/x/main.dart'); assert.strictEqual(g.getDependencies('/x/main.dart').length, 0); });
test('Package URI resolves through the supplied package configuration', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/app/lib/main.dart', "import 'package:demo/model.dart';"], ['/packages/demo/lib/model.dart', 'class Model {}']]); docs.packageConfig = new Map([['demo', '/packages/demo/lib']]); g.update(docs, '/app/lib/main.dart'); assert(g.getDependencies('/app/lib/main.dart').some(x => x.path === '/packages/demo/lib/model.dart')); });
test('Package configuration changes invalidate package-import consumers without reparsing source', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/app/lib/main.dart', "import 'package:demo/model.dart';"], ['/pkg1/lib/model.dart', 'class Model {}'], ['/pkg2/lib/model.dart', 'class Model {}']]); docs.packageConfig = new Map([['demo', '/pkg1/lib']]); g.update(docs, '/app/lib/main.dart'); const before = g.stats().parsedDocuments; docs.packageConfig = new Map([['demo', '/pkg2/lib']]); const result = g.update(docs, '/app/lib/main.dart'); assert.strictEqual(g.stats().parsedDocuments, before); assert(result.dependencyChanged.includes('/app/lib/main.dart')); assert(g.getDependencies('/app/lib/main.dart').some(x => x.path === '/pkg2/lib/model.dart')); });
test('Import cycles remain bounded and queryable', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/cycle/a.dart', "import 'b.dart'; class A {}"], ['/cycle/b.dart', "import 'a.dart'; class B {}"]]); g.update(docs, '/cycle/a.dart'); assert(g.getAffectedDocuments('/cycle/a.dart').includes('/cycle/b.dart')); });
test('Part directives link library documents to open part documents', () => { const g = api.createDartSemanticGraph(); const docs = new Map([['/lib/root.dart', "library demo;\npart 'part.dart';"], ['/lib/part.dart', "part of demo; class PartType {}"]]); g.update(docs, '/lib/root.dart'); assert(g.getDependencies('/lib/root.dart').some(x => x.path === '/lib/part.dart' && x.kind === 'part')); });
test('Graph enforces configured document bound', () => { const g = api.createDartSemanticGraph(2); g.update(new Map([['/p/a.dart','class A {}'],['/p/b.dart','class B {}'],['/p/c.dart','class C {}']]), '/p/c.dart'); assert.strictEqual(g.stats().documentCount, 2); assert(g.getDocument('/p/c.dart')); });
test('Statistics expose parsed, reused, edge, symbol and reference counts', () => { const stats = graph.stats(); assert(stats.parsedDocuments >= 4); assert(stats.reusedDocuments >= 4); assert(stats.dependencyEdges >= 0); assert(stats.symbolCount >= 0); assert(stats.referenceEdges >= 0); });
test('Clear releases documents and graph edges', () => { graph.clear(); assert.strictEqual(graph.stats().documentCount, 0); assert.strictEqual(graph.stats().dependencyEdges, 0); assert.strictEqual(graph.paths().length, 0); });
console.log(`RESULT ${passed}/${passed + failed} PASS`);
if (failed) process.exitCode = 1;
