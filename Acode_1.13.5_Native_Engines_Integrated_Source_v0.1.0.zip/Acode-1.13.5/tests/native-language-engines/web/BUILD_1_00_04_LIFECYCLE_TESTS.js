const assert = require('node:assert/strict');

const registered = { init: null, unmount: null };
const documentListeners = new Map();
class Compartment {
  of(extension) { return { compartment: this, extension }; }
  get(state) { return state.compartments?.get(this); }
  reconfigure(extension) { return { compartment: this, extension, reconfigure: true }; }
}
const completionApi = { pickedCompletion: { of: completion => ({ type: 'pickedCompletion', completion }) } };
const stateApi = {
  StateEffect: { appendConfig: { of: value => value } },
  Compartment,
  EditorState: { languageData: { of: provider => ({ languageDataProvider: provider }) } }
};
let editorText = '<di';
let editorSelection = { from: 3, to: 3, empty: true };
function makeDoc() {
  return {
    toString: () => editorText,
    sliceString: (from, to) => editorText.slice(from, to),
    lineAt(position) {
      const from = editorText.lastIndexOf('\n', Math.max(0, position - 1)) + 1;
      const found = editorText.indexOf('\n', position);
      return { from, to: found < 0 ? editorText.length : found };
    }
  };
}
const view = {
  state: {
    compartments: new Map(),
    get doc() { return makeDoc(); },
    get selection() { return { main: editorSelection }; }
  },
  dom: { contains: element => element === contentElement },
  contentDOM: null,
  dispatch(transaction) {
    this.lastTransaction = transaction;
    const effect = transaction?.effects;
    if (effect?.compartment) {
      if (effect.reconfigure && Array.isArray(effect.extension) && effect.extension.length === 0) {
        this.state.compartments.delete(effect.compartment);
      } else this.state.compartments.set(effect.compartment, effect.extension);
    }
    if (transaction?.changes) {
      const change = transaction.changes;
      editorText = editorText.slice(0, change.from) + change.insert + editorText.slice(change.to);
    }
    if (transaction?.selection?.anchor != null) {
      const anchor = transaction.selection.anchor;
      editorSelection = { from: anchor, to: anchor, empty: true };
    }
  }
};
const contentElement = { nodeType: 1 };
view.contentDOM = contentElement;
const manager = {
  isCodeMirror: true,
  editor: view,
  activeFile: { filename: '/workspace/index.html' },
  on() {}, off() {}
};

global.document = {
  addEventListener(name, callback) { documentListeners.set(name, callback); },
  removeEventListener(name) { documentListeners.delete(name); }
};
global.window = {
  __ACODE_HSTP_TESTING__: false,
  editorManager: manager,
  localStorage: { getItem: () => '1.00.01', setItem() {} },
  acode: {
    require(name) { return name === '@codemirror/state' ? stateApi : name === '@codemirror/autocomplete' ? completionApi : null; },
    setPluginInit(id, callback) { registered.init = callback; },
    setPluginUnmount(id, callback) { registered.unmount = callback; },
    pushNotification() {}
  }
};

require('../main.js');

function sendBeforeInput(character) {
  let prevented = false;
  const event = {
    inputType: 'insertText', data: character, isComposing: false,
    target: contentElement,
    composedPath: () => [contentElement, view.dom],
    preventDefault() { prevented = true; }
  };
  const listener = documentListeners.get('beforeinput');
  assert.equal(typeof listener, 'function', 'beforeinput handler should be registered');
  listener(event);
  return prevented;
}

(async () => {
  assert.equal(typeof registered.init, 'function', 'Acode init callback should be registered');
  assert.equal(typeof registered.unmount, 'function', 'Acode unmount callback should be registered');
  await registered.init();

  assert.equal(view.state.compartments.size, 1, 'one completion compartment should be attached');
  const extension = [...view.state.compartments.values()][0];
  const providers = extension.languageDataProvider();
  assert.equal(providers.length, 1, 'one language-data completion provider should be registered');
  const completion = providers[0].autocomplete({ state: { doc: { toString: () => '<di' } }, pos: 3 });
  assert.ok(completion.options.some(option => option.label === 'div'), 'completion source should offer div in HTML context');
  assert.equal(completion.filter, false, 'the source must preserve its prefix-filtered recent-use order without CodeMirror re-sorting');
  assert.ok(completion.options.every(option => typeof option.apply === 'function'), 'all suggestions should use the same standard completion apply contract');
  const divCompletion = completion.options.find(option => option.label === 'div');
  divCompletion.apply(view, divCompletion, completion.from, completion.to);
  assert.equal(editorText, '<div></div>', 'selecting a tag should replace the matched text with the complete paired tag');
  assert.equal(view.lastTransaction.annotations.type, 'pickedCompletion', 'custom apply must notify CodeMirror that a completion was picked');
  assert.equal(completion.options.find(option => option.label === 'div').displayLabel, '<div>', 'completion popup should show a full tag');

  const shorthand = providers[0].autocomplete({ state: { doc: { toString: () => 'h1' } }, pos: 2 });
  assert.ok(shorthand.options.some(option => option.label === 'h1' && option.displayLabel === '<h1>'), 'completion source should offer the <h1> shorthand');
  const htmlSnippet = providers[0].autocomplete({ state: { doc: { toString: () => '!html' } }, pos: 5 });
  assert.ok(htmlSnippet.options.some(option => option.label === '!html' && /multi-line HTML template/.test(option.detail)), 'completion source should offer multi-line HTML template');

  // Real editor-event path: type > after a manually entered <style and get a paired close tag.
  editorText = '<style';
  editorSelection = { from: 6, to: 6, empty: true };
  assert.equal(sendBeforeInput('>'), true, 'H.S.T.P should intercept the HTML opening-tag terminator');
  assert.equal(editorText, '<style></style>', 'style opening tag should receive </style>');
  assert.equal(editorSelection.from, 7, 'cursor should remain between style tags');

  // Real editor-event path: CSS braces create a multiline block with a matching brace.
  manager.activeFile = { filename: '/workspace/styles.css' };
  editorText = 'h1 ';
  editorSelection = { from: 3, to: 3, empty: true };
  assert.equal(sendBeforeInput('{'), true, 'H.S.T.P should intercept CSS opening braces');
  assert.equal(editorText, 'h1 {\n  \n}', 'CSS brace should create an indented block');
  assert.equal(editorSelection.from, 7, 'cursor should be positioned on the inner declaration line');

  // Balanced function delimiters and closing-character skip are wired to the live editor event.
  editorText = 'rgb';
  editorSelection = { from: 3, to: 3, empty: true };
  assert.equal(sendBeforeInput('('), true, 'H.S.T.P should pair CSS parentheses');
  assert.equal(editorText, 'rgb()', 'typing an opening parenthesis should insert its closing partner');
  assert.equal(editorSelection.from, 4, 'cursor should be inside the parentheses');
  assert.equal(sendBeforeInput(')'), true, 'H.S.T.P should skip an existing closing parenthesis');
  assert.equal(editorText, 'rgb()', 'skipping a closing parenthesis should not duplicate it');
  assert.equal(editorSelection.from, 5, 'cursor should move past the existing close character');

  await registered.unmount();
  assert.equal(view.state.compartments.size, 0, 'completion compartment should be removed on unmount');
  assert.equal(documentListeners.size, 0, 'document interaction and beforeinput listeners should be removed on unmount');
  console.log('PASS plugin init/unmount registration');
  console.log('PASS CodeMirror completion compartment attachment');
  console.log('PASS HTML completion provider integration');
  console.log('PASS standalone tag shorthand through provider');
  console.log('PASS multi-line snippet completion through provider');
  console.log('PASS unified completion callback contract and recent-order preservation');
  console.log('PASS custom apply emits CodeMirror pickedCompletion annotation');
  console.log('PASS manual HTML tag autoclose through beforeinput');
  console.log('PASS CSS brace pairing and indentation through beforeinput');
  console.log('PASS CSS parenthesis pairing and closing-character skip');
  console.log('PASS lifecycle cleanup and listener removal');
  console.log('SUMMARY 11/11 PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
