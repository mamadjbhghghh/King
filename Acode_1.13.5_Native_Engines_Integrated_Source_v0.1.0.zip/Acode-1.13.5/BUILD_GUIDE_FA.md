# راهنمای کامپایل Acode با موتورهای بومی Python، Dart و HTML/CSS

## فایل تحویلی

این پوشه سورس کامل Acode 1.13.5 است؛ سه موتور زبان در خود سورس قرار گرفته‌اند و هنگام راه‌اندازی Acode به‌صورت داخلی فعال می‌شوند. برای اجرای موتورهای اصلی، نصب جداگانه P.T.P، D.T.P یا H.S.T.P لازم نیست.

## پیش‌نیازها

- Node.js و npm سازگار با نسخه وابستگی‌های پروژه
- Java و Gradle موردنیاز Cordova Android در این نسخه
- Android SDK و ابزارهای build پلتفرم Android
- دسترسی به نصب وابستگی‌های npm و Cordova plugins

## مراحل کامپایل

از ریشه پوشه `Acode-1.13.5` اجرا کنید:

```bash
npm ci
npm run build -- paid dev apk
```

برای ساخت خروجی Production:

```bash
npm run build -- paid prod apk
```

خروجی Android توسط اسکریپت `utils/scripts/build.sh` و Cordova ساخته می‌شود. محل دقیق APK را خروجی Gradle/Cordova در پایان Build اعلام می‌کند.

## نکات مهم

1. این ZIP سورس است، APK آماده نیست.
2. در محیط فعلی، نصب وابستگی‌ها، Rspack، Gradle و ساخت APK اجرا نشده است؛ بنابراین موفقیت کامپایل هنوز تأیید نشده.
3. پس از نصب APK، ابتدا فایل‌های `.py`، `.dart`، `.html` و `.css` را جداگانه آزمایش کنید و سپس چندین بار بین آن‌ها جابه‌جا شوید.
4. اگر نسخه‌های مستقل این سه افزونه قبلاً در Acode نصب شده‌اند، موتورهای فعال مستقل هنگام راه‌اندازی خاموش می‌شوند و نسخه‌های بسته‌بندی‌شده داخل Acode جایگزین آن‌ها می‌شوند. برای جلوگیری از مصرف اضافه، پیشنهاد می‌شود افزونه‌های مستقل را پس از تأیید نسخه بومی حذف کنید.
5. در این کاندید، Pyodide Runtime و بسته 858 آیکونی Material Icons Advanced عمداً از مسیر فعال‌سازی جدا هستند. تمرکز این نسخه روی موتورهای تکمیل و تحلیل کد است؛ انتقال این دو ماژول مرحله جداگانه‌ای دارد.
6. هنوز لایه نهایی واحد برای ادغام سه completion provider در یک CodeMirror source ساخته نشده است. در این نسخه، هر موتور از adapter موجود خود استفاده می‌کند و براساس زبان/مسیر فایل فعال می‌شود.

## فایل‌های اصلی ادغام

- `src/main.js` — نقطه اتصال راه‌اندازی موتورهای داخلی
- `src/cm/nativeLanguageEngines.js` — bootstrap و lifecycle موتورهای بومی
- `src/cm/languageEngines/registry.ts` — registry مشترک
- `www/native-language-engines/python/main.js` — هسته P.T.P
- `www/native-language-engines/dart/main.js` — هسته D.T.P
- `www/native-language-engines/web/main.js` — هسته H.S.T.P

این نسخه را تا قبل از Build موفق و تست واقعی روی دستگاه Android، Stable تلقی نکنید.
