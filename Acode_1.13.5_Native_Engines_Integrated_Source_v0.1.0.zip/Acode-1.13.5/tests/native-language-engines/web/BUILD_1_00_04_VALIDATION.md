# H.S.T.P Build 1.00.04 — Validation Report

## Build identity
- Version: `1.00.04`
- Plugin ID: `com.jarvis.html-css-toolkit-pro`
- Main entry: `main.js`

## Automated validation

| Check | Result |
|---|---:|
| JavaScript syntax (`node --check main.js`) | PASS |
| Engine tests | 82/82 PASS |
| Lifecycle / CodeMirror integration tests | 11/11 PASS |
| Total automated assertions | 93/93 PASS |
| Manifest version matches build | PASS |
| ZIP root layout | PASS |
| ZIP CRC integrity | PASS |
| All manifest-declared files present | PASS |

## Main verified behaviors

- Snippets are ordinary CodeMirror completion entries, not a separate preview/popup type.
- Custom apply transactions include CodeMirror's `pickedCompletion` annotation when available.
- Choosing `!html` replaces the complete trigger with exactly one HTML5 document and positions the cursor in the title.
- HTML and CSS snippet rows use the same completion type and a uniform apply callback contract.
- Context parsers strictly filter suggestions; `filter: false` preserves their prepared ordering in CodeMirror.
- Accepted completions are recorded to local storage using the shared Toolkit Pro family schema.
- Most recently used matching items rank first and persist through restart, when local storage is available.

## Important limitation

Automated tests use Node.js mocks for the Acode and CodeMirror APIs. They cannot prove actual device popup behavior or Acode's Android runtime integration. The build remains **Candidate** until all 13 real-device tests in `BUILD_1_00_04_ACODE_TESTS_FA.txt` pass.
