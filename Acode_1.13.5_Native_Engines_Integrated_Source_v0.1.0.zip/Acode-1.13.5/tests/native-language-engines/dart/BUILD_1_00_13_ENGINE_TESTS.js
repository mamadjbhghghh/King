const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const code = fs.readFileSync(__dirname + '/../main.js', 'utf8');
const sandbox = { window: { __ACODE_DTP_TESTING__: true }, console, setTimeout, clearTimeout, setInterval, clearInterval, Date, URL };
vm.runInNewContext(code, sandbox);
const api = sandbox.window.__acodeDTPTest;
let passed = 0, failed = 0;
function test(name, fn) { try { fn(); passed++; console.log('PASS ' + name); } catch (error) { failed++; console.error('FAIL ' + name + ': ' + error.message); } }

const project = `import 'dart:async';
abstract class Repository<T> {
  final T value;
  Repository(this.value);
  Future<T> load() async { return value; }
  String get label => value.toString();
  set label(String next) {}
}
enum Status { ready, busy }
mixin Traceable { void trace() {} }
extension TextTools on String { String shout() => toUpperCase(); }
typedef Mapper<T> = T Function(T);
Future<void> main() async {
  final String title = 'Dart';
  final List<int>? counts = <int>[];
  var total = 42;
  for (final item in <String>[]) { item.toUpperCase(); }
  for (var index = 0; index < 2; index++) { print(index); }
  if (total > 0) { print(title); }
}`;
const ast = api.parseDartAst(project);

// Version and lexical offsets.
test('Build version is 1.00.13', () => assert.strictEqual(api.TOOLKIT_VERSION, '1.00.13'));
test('Lexer preserves exact token offsets', () => { const x = api.lexDartSource('final name = "Ada";'); assert.strictEqual('final name = "Ada";'.slice(x.tokens[0].start, x.tokens[0].end), 'final'); assert.strictEqual('final name = "Ada";'.slice(x.tokens[3].start, x.tokens[3].end), '"Ada"'); });
test('Line comments are omitted from code tokens and retained as trivia', () => { const x = api.lexDartSource('final x = 1; // class Fake {}'); assert.strictEqual(x.tokens.some(t => t.value === 'Fake'), false); assert.strictEqual(x.comments.length, 1); });
test('Block comments do not create declarations', () => { const x = api.parseDartAst('/* class Ghost {} */ class Real {}'); assert.strictEqual(Array.from(x.declarations, d => d.name).join(','), 'Real'); });
test('Single quoted strings are atomic tokens', () => { const x = api.lexDartSource("final s = 'class Fake {}';"); assert.strictEqual(x.tokens.filter(t => t.type === 'string').length, 1); });
test('Triple quoted strings are atomic tokens', () => { const x = api.lexDartSource('final s = """class Fake {\n void ghost() {} }""";'); assert.strictEqual(x.tokens.some(t => t.value === 'ghost'), false); });
test('Raw strings are tokenized without escape processing', () => { const x = api.lexDartSource("final s = r'\\n';"); assert.strictEqual(x.tokens.find(t => t.type === 'string').value, "r'\\n'"); });
test('Unclosed strings produce offset diagnostics', () => { const x = api.lexDartSource("final s = 'unfinished"); assert(x.diagnostics.some(d => d.code === 'ast-unclosed-string' && d.from === 10)); });
test('Unclosed block comments produce diagnostics', () => { const x = api.lexDartSource('void main() { /* unfinished'); assert(x.diagnostics.some(d => d.code === 'ast-unclosed-comment')); });

// Declaration tree.
test('Compilation unit exposes its declaration and directive collections', () => { assert.strictEqual(ast.kind, 'CompilationUnit'); assert.strictEqual(ast.directives.length, 1); assert(ast.metrics.tokenCount > 50); });
test('Generic abstract class declaration is indexed', () => { const x = ast.declarations.find(d => d.name === 'Repository'); assert(x && x.kind === 'ClassDeclaration'); assert(x.header.includes('Repository<T>')); });
test('Enum declaration is indexed', () => assert(ast.declarations.some(d => d.kind === 'EnumDeclaration' && d.name === 'Status')));
test('Mixin declaration is indexed', () => assert(ast.declarations.some(d => d.kind === 'MixinDeclaration' && d.name === 'Traceable')));
test('Extension declaration is indexed', () => assert(ast.declarations.some(d => d.kind === 'ExtensionDeclaration' && d.name === 'TextTools')));
test('Typedef type alias target is retained', () => { const x = ast.declarations.find(d => d.kind === 'TypedefDeclaration'); assert.strictEqual(x.name, 'Mapper'); assert(x.target.includes('Function')); });
test('Async top-level function declaration and return type are indexed', () => { const x = ast.declarations.find(d => d.kind === 'FunctionDeclaration' && d.name === 'main'); assert(x); assert.strictEqual(x.returnType, 'Future<void>'); });
test('Class field declaration captures explicit type', () => { const x = ast.declarations.find(d => d.name === 'Repository').children.find(m => m.name === 'value'); assert.strictEqual(x.kind, 'FieldDeclaration'); assert.strictEqual(x.returnType, 'T'); });
test('Constructor declaration is indexed', () => assert(ast.declarations.find(d => d.name === 'Repository').children.some(m => m.kind === 'ConstructorDeclaration')));
test('Method declaration captures name, return type and parameters', () => { const x = ast.declarations.find(d => d.name === 'Repository').children.find(m => m.name === 'load'); assert.strictEqual(x.kind, 'MethodDeclaration'); assert.strictEqual(x.returnType, 'Future<T>'); });
test('Getter declaration is indexed distinctly', () => assert(ast.declarations.find(d => d.name === 'Repository').children.some(m => m.kind === 'GetterDeclaration' && m.name === 'label')));
test('Setter declaration is indexed distinctly', () => assert(ast.declarations.find(d => d.name === 'Repository').children.some(m => m.kind === 'SetterDeclaration' && m.name === 'label')));
test('Class member owner association is retained', () => assert(ast.declarations.find(d => d.name === 'Repository').children.every(m => m.owner === 'Repository')));
test('Un-named extension declaration is accepted without a false missing-name error', () => { const x = api.parseDartAst('extension on String { int get size => length; }'); assert.strictEqual(x.diagnostics.some(d => d.code === 'ast-missing-type-name'), false); });
test('Malformed class declaration reports missing type name', () => { const x = api.parseDartAst('class { int value = 1; }'); assert(x.diagnostics.some(d => d.code === 'ast-missing-type-name')); });
test('Nested delimiters produce matched delimiter metadata', () => { const x = api.parseDartAst('void f() { final x = [1, (2 + 3)]; }'); assert(x.delimiterPairs.length >= 4); });

// Blocks, statements and declarations.
test('Class and function bodies are classified as scopes', () => { assert(ast.blocks.some(b => b.kind === 'ClassBody' && b.ownerName === 'Repository')); assert(ast.blocks.some(b => b.kind === 'FunctionBody' && b.ownerName === 'main')); });
test('Control-flow statements are represented in syntax inventory', () => { assert(ast.statements.some(s => s.keyword === 'if')); assert(ast.statements.some(s => s.keyword === 'for')); });
test('AST indexes local explicit declarations', () => { const x = ast.variables.find(v => v.name === 'title'); assert(x && x.declaredType === 'String'); });
test('AST preserves nullable generic local annotations', () => { const x = ast.variables.find(v => v.name === 'counts'); assert(x && x.declaredType === 'List<int>?'); });
test('AST indexes inferred local declarations', () => { const x = ast.variables.find(v => v.name === 'total'); assert(x && x.initializer === '42'); });
test('Loop-in binding records the iterable element type', () => { const x = ast.variables.find(v => v.name === 'item'); assert(x && x.isLoopBinding); assert.strictEqual(x.loopElementType, 'String'); });
test('Classic for-loop initializer is marked as loop-scoped', () => { const x = ast.variables.find(v => v.name === 'index'); assert(x && x.isLoopBinding); });
test('Formal parameters are not misclassified as local variable declarations', () => { const x = api.parseDartAst('void f(final String arg) { print(arg); }'); assert.strictEqual(x.variables.some(v => v.name === 'arg'), false); });
test('Loop binding scope starts at loop body and excludes following code', () => { const src = 'void f() { for (final item in <String>[]) { item; } item; }'; const v = api.parseDartAst(src).variables.find(x => x.name === 'item'); assert(v); assert(v.scopeStart > src.indexOf('for')); assert(v.scopeEnd < src.lastIndexOf('item;')); });
test('Loop binding infers its element type inside loop body', () => { const src = 'void f() { for (final item in <String>[]) { item.toUpperCase(); } }'; const pos = src.indexOf('item.toUpperCase') + 4; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.get('item'), 'String'); });
test('Loop binding does not leak after loop', () => { const src = 'void f() { for (final item in <String>[]) { print(item); } print(item); }'; const pos = src.lastIndexOf('print(item)') + 11; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.has('item'), false); });
test('Classic for-loop initializer infers numeric type inside body', () => { const src = 'void f() { for (var index = 0; index < 3; index++) { index.to; } }'; const pos = src.indexOf('index.to') + 5; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.get('index'), 'int'); });
test('Typed classic for-loop declaration retains its explicit type', () => { const src = 'void f() { for (int index = 0; index < 3; index++) { index.to; } }'; const ast = api.parseDartAst(src); const item = ast.variables.find(v => v.name === 'index'); assert(item && item.isLoopBinding); assert.strictEqual(item.declaredType, 'int'); });
test('Typed for-in declaration is scoped and retains its explicit type', () => { const src = 'void f() { for (String item in values) { item.to; } print(item); }'; const ast = api.parseDartAst(src); const item = ast.variables.find(v => v.name === 'item'); assert(item && item.isLoopBinding); assert.strictEqual(item.declaredType, 'String'); const inTypes = api.inferLocalTypes(src, src.indexOf('item.to') + 8, api.analyzeDartSymbols(src), ast); const outTypes = api.inferLocalTypes(src, src.lastIndexOf('print(item)') + 11, api.analyzeDartSymbols(src), ast); assert.strictEqual(inTypes.get('item'), 'String'); assert.strictEqual(outTypes.has('item'), false); });
test('Outer declaration survives a same-name loop shadow after the loop', () => { const src = 'void f() { int index = 9; for (var index = 0; index < 2; index++) { print(index); } print(index); }'; const pos = src.lastIndexOf('print(index)') + 12; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.get('index'), 'int'); });
test('Classic for-loop initializer does not leak after body', () => { const src = 'void f() { for (var index = 0; index < 3; index++) { print(index); } print(index); }'; const pos = src.lastIndexOf('print(index)') + 12; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.has('index'), false); });
test('Nullable explicitly typed local is retained by AST fallback', () => { const src = 'void f() { final String? value = null; value; }'; const pos = src.indexOf('value;') + 5; const types = api.inferLocalTypes(src, pos, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(types.get('value'), 'String?'); });
test('Incomplete source still returns a recoverable compilation unit', () => { const x = api.parseDartAst('class User { void run() { final value = "x";'); assert.strictEqual(x.kind, 'CompilationUnit'); assert(x.declarations.some(d => d.name === 'User')); });
test('Pattern-like text in comments is ignored by parser', () => { const x = api.parseDartAst('// class Phantom {}\nfinal x = "typedef Fake = int;"; class Actual {}'); assert.strictEqual(Array.from(x.declarations, d => d.name).join(','), 'Actual'); });

test('Enum constants are parsed as enum members', () => { const x = api.parseDartAst('enum State { ready, busy, off }'); const e = x.declarations.find(d => d.kind === 'EnumDeclaration'); assert.strictEqual(Array.from(e.children, m => m.name).join(','), 'ready,busy,off'); });
test('Field initializer constructor calls are not mistaken for methods', () => { const x = api.parseDartAst('class Box { final List<String> values = List<String>(); }'); const f = x.declarations[0].children.find(m => m.name === 'values'); assert.strictEqual(f.kind, 'FieldDeclaration'); assert.strictEqual(f.returnType, 'List<String>'); });

// Cached document analysis.
test('Analysis cache reuses identical document parse', () => { const c = api.createDartAnalysisCache(3); const a = c.analyze('/p/main.dart', 'class A {}'); const b = c.analyze('/p/main.dart', 'class A {}'); assert.strictEqual(a, b); assert.strictEqual(c.stats().hits, 1); });
test('Analysis cache invalidates by changed document content', () => { const c = api.createDartAnalysisCache(3); const a = c.analyze('/p/main.dart', 'class A {}'); const b = c.analyze('/p/main.dart', 'class B {}'); assert.notStrictEqual(a, b); assert.strictEqual(b.declarations[0].name, 'B'); });
test('Analysis cache maintains independent paths', () => { const c = api.createDartAnalysisCache(3); const a = c.analyze('/p/a.dart', 'class A {}'); const b = c.analyze('/p/b.dart', 'class B {}'); assert.notStrictEqual(a, b); assert.strictEqual(c.stats().size, 2); });
test('Analysis cache enforces bounded LRU size', () => { const c = api.createDartAnalysisCache(2); c.analyze('/p/a.dart', 'class A {}'); c.analyze('/p/b.dart', 'class B {}'); c.analyze('/p/a.dart', 'class A {}'); c.analyze('/p/c.dart', 'class C {}'); assert.strictEqual(c.stats().size, 2); assert.strictEqual(c.stats().limit, 2); });
test('Analysis cache supports explicit path invalidation', () => { const c = api.createDartAnalysisCache(2); c.analyze('/p/a.dart', 'class A {}'); assert.strictEqual(c.invalidate('/p/a.dart'), true); assert.strictEqual(c.stats().size, 0); });
test('Analysis cache clear resets entries and counters', () => { const c = api.createDartAnalysisCache(2); c.analyze('/p/a.dart', 'class A {}'); c.analyze('/p/a.dart', 'class A {}'); c.clear(); assert.deepStrictEqual(JSON.parse(JSON.stringify(c.stats())), { size: 0, hits: 0, misses: 0, limit: 2 }); });


// Pratt expression parser and expression-driven semantic inference.
const basicSymbols = { classes: new Map(), functions: [], extensions: [], typedefs: new Map(), prefixes: new Map() };
test('Expression parser respects arithmetic precedence', () => { const x = api.parseDartExpression('1 + 2 * 3').expression; assert.strictEqual(x.kind, 'BinaryExpression'); assert.strictEqual(x.operator, '+'); assert.strictEqual(x.right.operator, '*'); });
test('Parenthesized expressions retain grouping nodes', () => { const x = api.parseDartExpression('(1 + 2) * 3').expression; assert.strictEqual(x.left.kind, 'ParenthesizedExpression'); });
test('Member access and invocation form nested expression nodes', () => { const x = api.parseDartExpression('user.profile.name.toUpperCase()').expression; assert.strictEqual(x.kind, 'CallExpression'); assert.strictEqual(x.callee.member, 'toUpperCase'); assert.strictEqual(x.callee.object.member, 'name'); });
test('Indexing parses as a distinct expression node', () => { const x = api.parseDartExpression('values[index]').expression; assert.strictEqual(x.kind, 'IndexExpression'); assert.strictEqual(x.object.name, 'values'); });
test('Named and positional record expressions are distinguished', () => { const p = api.parseDartExpression("('Ada', 37)").expression; const n = api.parseDartExpression("(name: 'Ada', age: 37)").expression; assert.strictEqual(p.kind, 'RecordLiteral'); assert.strictEqual(p.positional.length, 2); assert.strictEqual(n.named.length, 2); });
test('Typed list literals preserve generic element annotation', () => { const x = api.parseDartExpression("<String>['a', 'b']").expression; assert.strictEqual(x.kind, 'ListLiteral'); assert.strictEqual(api.inferDartExpressionAstType(x, basicSymbols), 'List<String>'); });
test('Typed map literals preserve key and value types', () => { const x = api.parseDartExpression("<String, int>{'age': 37}").expression; assert.strictEqual(x.kind, 'MapLiteral'); assert.strictEqual(api.inferDartExpressionAstType(x, basicSymbols), 'Map<String, int>'); });
test('Untyped collection literal elements infer a common type', () => { const x = api.parseDartExpression('[1, 2, 3]').expression; assert.strictEqual(api.inferDartExpressionAstType(x, basicSymbols), 'List<int>'); });
test('Conditional expressions infer from branches rather than condition', () => { assert.strictEqual(api.inferExpressionType("true ? 'yes' : 'no'", basicSymbols), 'String'); });
test('Null coalescing with a null literal infers fallback type', () => { assert.strictEqual(api.inferExpressionType("null ?? 'fallback'", basicSymbols), 'String'); });
test('String concatenation is inferred from its expression tree', () => { assert.strictEqual(api.inferExpressionType("'age: ' + 37", basicSymbols), 'String'); });
test('Integer arithmetic remains int', () => { assert.strictEqual(api.inferExpressionType('10 + 20 * 2', basicSymbols), 'int'); });
test('Division expression infers double', () => { assert.strictEqual(api.inferExpressionType('10 / 2', basicSymbols), 'double'); });
test('Comparison and logical expressions infer bool', () => { assert.strictEqual(api.inferExpressionType('1 < 2 && true', basicSymbols), 'bool'); });
test('List index expression infers element type', () => { assert.strictEqual(api.inferExpressionType("<String>['a'][0]", basicSymbols), 'String'); });
test('Map index expression infers value type', () => { assert.strictEqual(api.inferExpressionType("<String, int>{'age': 37}['age']", basicSymbols), 'int'); });
test('Await unwraps a generic Future result type', () => { assert.strictEqual(api.inferExpressionType('await Future<int>.value(3)', basicSymbols), 'int'); });
test('Generic static List factory retains its element type', () => { assert.strictEqual(api.inferExpressionType("List<String>.filled(3, '')", basicSymbols), 'List<String>'); });
test('Null assertion removes nullable marker', () => { assert.strictEqual(api.inferExpressionType('value!', basicSymbols, new Map([['value', 'String?']])), 'String'); });
test('Type-test expression infers bool', () => { assert.strictEqual(api.inferExpressionType('value is String', basicSymbols), 'bool'); });
test('Cast expression returns asserted target type', () => { assert.strictEqual(api.inferExpressionType('value as String', basicSymbols), 'String'); });
test('Arrow function expression is represented in the tree', () => { const x = api.parseDartExpression('(value) => value + 1').expression; assert.strictEqual(x.kind, 'FunctionExpression'); });
test('Expression nodes preserve absolute source offsets', () => { const x = api.parseDartExpression('value + 1', 120).expression; assert.strictEqual(x.start, 120); assert.strictEqual(x.end, 129); });
test('Variable declarations retain parsed initializer AST and offsets', () => { const src = 'void main() { final number = 1 + 2; }'; const item = api.parseDartAst(src).variables.find(v => v.name === 'number'); assert(item.initializerAst); assert.strictEqual(src.slice(item.initializerStart, item.initializerEnd), '1 + 2'); assert.strictEqual(item.initializerAst.expression.kind, 'BinaryExpression'); });
test('Control-flow condition is attached as an expression tree', () => { const src = 'void main() { if (count > 0 && ready) { run(); } }'; const item = api.parseDartAst(src).statements.find(v => v.keyword === 'if'); assert(item.conditionAst); assert.strictEqual(item.conditionAst.expression.operator, '&&'); });
test('Return payload is attached as an expression tree', () => { const src = 'int value() { return 1 + 2; }'; const item = api.parseDartAst(src).statements.find(v => v.keyword === 'return'); assert(item.expressionAst); assert.strictEqual(item.expressionAst.expression.operator, '+'); });
test('Local collection indexing flows into subsequent member inference', () => { const src = "void main() { final values = <String>['Ada']; final item = values[0]; item.toUpperCase(); }"; const map = api.inferLocalTypes(src, src.length - 2, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(map.get('values'), 'List<String>'); assert.strictEqual(map.get('item'), 'String'); });
test('Conditional initializer does not inherit boolean condition type', () => { const src = "void main() { final label = 'Ada'; final result = true ? label : 'Grace'; result.toUpperCase(); }"; const map = api.inferLocalTypes(src, src.length - 2, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(map.get('result'), 'String'); });
test('Await initializer infers Future payload type', () => { const src = 'void main() async { final count = await Future<int>.value(3); count.toInt(); }'; const map = api.inferLocalTypes(src, src.length - 2, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(map.get('count'), 'int'); });
test('User-defined member call chain resolves return type', () => { const src = 'class User {\n String name;\n String greet() => name;\n}\nvoid main() { final user = User(); final greeting = user.greet().toUpperCase(); }'; const map = api.inferLocalTypes(src, src.length - 2, api.analyzeDartSymbols(src), api.parseDartAst(src)); assert.strictEqual(map.get('greeting'), 'String'); });
test('Incomplete expression input recovers without throwing', () => { const x = api.parseDartExpression('items[0].'); assert.strictEqual(x.kind, 'ExpressionUnit'); assert(x.expression); });

test('Incomplete member access is marked as a recoverable parser warning', () => { const x = api.parseDartExpression('items[0].'); assert.strictEqual(x.complete, false); assert(x.diagnostics.some(d => d.code === 'expression-incomplete-tail')); });
test('Await on a non-Future expression preserves its value type', () => { assert.strictEqual(api.inferExpressionType('await 3', basicSymbols), 'int'); });
test('Conditional expression with null branch preserves nullability', () => { assert.strictEqual(api.inferExpressionType("true ? 'Ada' : null", basicSymbols), 'String?'); });
test('Deeply nested expression input is bounded and does not overflow', () => { const src = '('.repeat(160) + '1' + ')'.repeat(160); const result = api.parseDartExpression(src); assert.strictEqual(result.kind, 'ExpressionUnit'); });
test('Generic collection factory supports named construction methods', () => { assert.strictEqual(api.inferExpressionType("Map<String, int>.from({'age': 37})", basicSymbols), 'Map<String, int>'); });

test('Classic for header separates condition and update expressions', () => { const x = api.parseDartAst('void main() { for (var i = 0; i < 3; i++) { print(i); } }'); const loop = x.statements.find(s => s.keyword === 'for'); assert.strictEqual(loop.forHeaderKind, 'classic'); assert.strictEqual(loop.conditionAst.expression.operator, '<'); assert.strictEqual(loop.updateAst.expression.kind, 'PostfixExpression'); });
test('For-in header stores iterable expression without mislabeling it as a condition', () => { const x = api.parseDartAst('void main() { for (final item in <String>[\'a\']) { print(item); } }'); const loop = x.statements.find(s => s.keyword === 'for'); assert.strictEqual(loop.forHeaderKind, 'for-in'); assert.strictEqual(loop.iterableAst.expression.kind, 'ListLiteral'); assert.strictEqual(loop.conditionAst, undefined); });



test('Simple typedef local resolves to its underlying String members', () => { const src = "typedef UserName = String; UserName name = 'Ada'; name.toU"; const labels = (api.resolveCompletions('lib/main.dart', src, src.length)?.options || []).map(x => x.label); assert(labels.includes('toUpperCase')); });
test('Generic typedef local preserves List element type for member completion', () => { const src = "typedef TypedList<T> = List<T>; TypedList<int> values = <int>[]; values.ad"; const labels = (api.resolveCompletions('lib/main.dart', src, src.length)?.options || []).map(x => x.label); assert(labels.includes('add')); });
test('Imported typedef local resolves to underlying SDK type', () => { const docs = new Map([['/p/main.dart', "import 'aliases.dart'; UserName name='Ada'; name.toU"], ['/p/aliases.dart', 'typedef UserName = String;']]); const ctx = api.buildProjectSemanticContext('/p/main.dart', docs.get('/p/main.dart'), docs); const labels = (api.resolveCompletions('/p/main.dart', "UserName name='Ada'; name.toU", "UserName name='Ada'; name.toU".length, ctx)?.options || []).map(x => x.label); assert(labels.includes('toUpperCase')); });
test('Re-exported typedef local retains alias resolution after export traversal', () => { const docs = new Map([['/p/main.dart', "import 'barrel.dart'; UserName name='Ada'; name.toU"], ['/p/barrel.dart', "export 'aliases.dart';"], ['/p/aliases.dart', 'typedef UserName = String;']]); const ctx = api.buildProjectSemanticContext('/p/main.dart', docs.get('/p/main.dart'), docs); const src = "UserName name='Ada'; name.toU"; const labels = (api.resolveCompletions('/p/main.dart', src, src.length, ctx)?.options || []).map(x => x.label); assert(labels.includes('toUpperCase')); });

console.log(`RESULT ${passed}/${passed + failed} PASS`);
if (failed) process.exitCode = 1;
