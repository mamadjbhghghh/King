export { default } from "./welcome";
